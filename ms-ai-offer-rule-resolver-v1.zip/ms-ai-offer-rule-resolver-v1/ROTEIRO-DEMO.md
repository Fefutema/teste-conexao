# Roteiro da demonstração (POC)

O show é o **serviço real rodando**: negócio manda a oferta + frases em português,
o Azure gpt-4o compila para a DSL técnica, o serviço valida + simula (tabela-verdade)
e devolve. Business pode jogar **ofertas novas ao vivo** — a oferta é input do
request, então não tem redeploy nem mexer em código.

Dois públicos:
- **Negócio:** "escrevo em português e o sistema compila + me mostra o preview auditável".
- **Time técnico do executor:** "esta é a DSL e a semântica exata que o executor deve reproduzir".

---

## Parte 1 (PRINCIPAL) — o serviço rodando, ao vivo

### Subir (única dependência externa = Azure; banco é H2 em memória via perfil `demo`)

```bash
export AZURE_OPENAI_ENDPOINT="https://SEU-RECURSO.openai.azure.com"
export AZURE_OPENAI_API_KEY="..."
export AZURE_OPENAI_DEPLOYMENT="gpt-4o"

mvn spring-boot:run -Dspring-boot.run.profiles=demo
```

> O perfil `demo` usa H2 em memória — **não precisa de Postgres**. Sem o perfil, o
> serviço espera um Postgres (produção).

### Chamar (frase em PT-BR -> regra técnica)

```bash
curl -s http://localhost:8080/api/v1/rules/compile \
  -H 'Content-Type: application/json' \
  -d @demo/request-compile.json | jq
```

Na resposta, mostre para cada regra: a **regra compilada** (DSL técnica), a
**confiança**, o **`requiresHumanReview`** e o **`preview`** (tabela-verdade).

**O que dizer:**
- **Negócio:** "mandei 3 frases; o sistema traduziu para a DSL, **validou** (produtos existem, janelas sãs), **simulou** as combinações e marcou `requiresHumanReview` — nada vai pro ar sem um humano aprovar".
- **Técnico:** "a saída é a linguagem técnica que o executor de vocês vai rodar".

### Ofertas novas ao vivo (o pedido típico do negócio)

Basta editar o `offerJson` no corpo e chamar de novo — **sem redeploy**. Ex.: troque
o `celular-b` por `iphone-17`, adicione um grupo `streaming`, e repita o `curl`.
Cada `POST` é independente; a oferta nunca fica "hardcoded".

```bash
# edite demo/request-compile.json (ou mande inline) e repita:
curl -s http://localhost:8080/api/v1/rules/compile -H 'Content-Type: application/json' -d @demo/request-compile.json | jq
```

Endpoints úteis: `GET /api/v1/rules/schema` (o JSON Schema da DSL), `GET /actuator/health`.

---

## Parte 2 (PLANO B) — determinístico, se o Azure falhar no palco

Se a rede/credencial do Azure der problema, você ainda mostra a **semântica** sem
depender de nada externo:

**Opção A — pipeline completo com a LLM mockada** (mostra o fluxo do serviço):
```bash
mvn -q -Dtest=RuleCompilationServiceIT test
```

**Opção B — só o DSL e as tabelas-verdade** (para o time técnico):
```bash
mvn -q compile
java -cp target/classes com.empresa.offerruleresolver.demo.DslDemo
```

> O `DslDemo` NÃO usa LLM — ele fixa as regras e imprime as tabelas-verdade. Serve
> de rede de segurança e de artefato para o time do executor, não é o show principal.

---

## Encerramento (o que cada público leva)

- **Negócio:** o MVP entrega o essencial — escrever regra em PT-BR e receber um preview validado, com revisão humana no início; e dá pra experimentar ofertas novas na hora.
- **Time técnico:** a DSL e a semântica estão prontas e demonstradas; o próximo passo é o executor reproduzir o `RuleEvaluator` — o contrato e os vetores de teste estão em [CONTRATO-SEMANTICO-RUNTIME.md](CONTRATO-SEMANTICO-RUNTIME.md).

> **Sobre manter o DSL só no código (sem virar biblioteca) nesta fase:** é o certo
> para o POC. A extração para uma lib compartilhada (`offer-rule-dsl`) é decisão de
> PRODUÇÃO — quando o executor começar a valer e você precisar de paridade garantida
> entre serviços (Estratégia 1 do contrato).
