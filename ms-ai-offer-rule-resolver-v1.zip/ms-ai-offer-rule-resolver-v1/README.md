# ms-ai-offer-rule-resolver-v1

Microsserviço que **compila regras de oferta escritas em linguagem natural (PT-BR)**
para uma **DSL estruturada**, validada de forma determinística, executada em
sandbox (tabela-verdade) e revisada por uma juíza semântica via LLM.

- **Spring Boot 4.1.0** · **Spring AI 2.0.0** · **Java 17**
- **Provider:** Azure OpenAI, **modelo único `gpt-4o`** (tradutor e juíza)
- **Arquitetura:** camadas MVC (`controller` → `service` → `repository`)

> Princípio: **a LLM é um compilador, não a autoridade final.** Toda saída passa
> pelo validador determinístico; a juíza compara *comportamento* (não JSON); nas
> primeiras semanas, **tudo vai a revisão humana**.

---

## Arquitetura em camadas

```
HTTP ─► controller ─► service ─► repository ─► PostgreSQL
                         │
                         ├─ ChatModel (Azure gpt-4o)   ← tradutor e juíza
                         └─ RuleEvaluator (semântica determinística da DSL)
```

Fluxo (por regra): `parse oferta → traduz+valida (retry) → sandbox → juíza → score → auditoria`.

| Camada | Pacote | Responsabilidade |
|---|---|---|
| controller | `controller` | REST fino; delega ao service |
| service | `service` | orquestrador + etapas (context, translator, validator, sandbox, judge, scorer) |
| repository | `repository` | auditoria (`compilation_log`) |
| domínio | `model.dsl`, `model.offer`, `model.dto` | DSL, oferta canônica, contratos |

### Os dois pontos voláteis (isolados de propósito)

- **Formato do `offerJson`** → atrás de `model.offer.OfferParser`. O pipeline só
  vê `OfferCatalog` (mínimo). Mudou o formato? Nova implementação de parser, nada
  mais muda.
- **A DSL** → semântica concentrada em `model.dsl.RuleEvaluator` (um `switch`).
  Mudou a DSL? Edita esse arquivo (+ prompt + golden-set). O JSON Schema é
  **derivado** do record `CompiledRule` (sem `.json` mantido à mão).

---

## Pré-requisito de build

Este projeto exige **Spring AI 2.0.0** e **Spring Boot 4.1.0**. Se essas versões
ainda não estão no seu `~/.m2` (ex.: você usa o Spring AI a partir do fonte),
instale-as primeiro — no repositório do Spring AI 2.0.0:

```bash
./mvnw install -DskipTests    # popula o ~/.m2 com os artefatos 2.0.0
```

## Como rodar

### 1. Testes (sem credenciais, LLM mockada, H2)

```bash
mvn test
```

Cobre validador, semântica da DSL, sandbox e o pipeline integrado (fiação das
camadas com a LLM mockada).

### 2. Subir localmente

Banco (Postgres via Docker):

```bash
docker run --name offerrules -e POSTGRES_DB=offerrules -e POSTGRES_PASSWORD=postgres -p 5432:5432 -d postgres:16
```

Variáveis do Azure OpenAI:

```bash
export AZURE_OPENAI_ENDPOINT="https://SEU-RECURSO.openai.azure.com"
export AZURE_OPENAI_API_KEY="..."
export AZURE_OPENAI_DEPLOYMENT="gpt-4o"     # nome do DEPLOYMENT no Azure
mvn spring-boot:run
```

### 3. Chamar a API

```bash
curl -s http://localhost:8080/api/v1/rules/compile \
  -H 'Content-Type: application/json' \
  -d '{
    "offerJson": { "offerId":"combo-1","slots":[
      {"id":"phone","minQty":1,"maxQty":1,"options":[{"id":"iphone-15"},{"id":"galaxy-s24"}]},
      {"id":"case","minQty":0,"maxQty":1,"options":[{"id":"case-silicone"}]},
      {"id":"streaming","minQty":0,"maxQty":1,"options":[{"id":"netflix-12m"}]}
    ]},
    "naturalLanguageRules": ["O celular é obrigatório."],
    "locale": "pt-BR"
  }'
```

Outros endpoints: `GET /api/v1/rules/schema` (JSON Schema da DSL), `GET /actuator/health`.

---

## Configuração relevante (`application.yaml`, prefixo `offer-rule-resolver`)

| Chave | Default | O que faz |
|---|---|---|
| `translator.max-retries` | 2 | tentativas de self-correction (erro do validador reinjetado) |
| `translator.strict-schema` | false | `true` = JSON Schema nativo estrito (exige gpt-4o ≥ 2024-08-06) |
| `confidence.force-human-review` | true | trava de segurança: tudo vira `NEEDS_REVIEW` |
| `confidence.auto-approve-threshold` | 0.90 | acima disso, auto-aprova (quando a trava sair) |
| `sandbox.max-scenarios` | 64 | teto de cenários na tabela-verdade |

---

## Duas fases

- **Fase 1 (este código):** pipeline ponta-a-ponta **com juíza**, validador,
  sandbox, auditoria, tudo em revisão humana.
- **Fase 2:** self-consistency (votação comportamental k-amostras) como confiança
  objetiva; golden-set em CI; observabilidade (Prometheus/Grafana); cache/
  idempotência; relaxar `force-human-review` com dados.

---

## Pontos de atenção (verifique no seu ambiente)

1. **Structured output estrito** (`translator.strict-schema=true`): o Spring AI
   força `strict=true` no JSON Schema — todos os campos precisam ser `required`.
   O default (`false`, instruções no prompt) é mais robusto; ligue o estrito só
   após confirmar o deployment. Requer gpt-4o ≥ 2024-08-06.
2. **Nomes de propriedade do Azure** (`microsoft-foundry`, `deployment-name`):
   derivados do código do Spring AI 2.0.0. Como a versão é recente, confirme
   contra a documentação da sua build.
3. **Jackson 3/2:** a oferta chega como `Map<String,Object>` de propósito, para
   evitar acoplamento ao pacote do Jackson (`tools.jackson` vs `com.fasterxml`).
4. **Semântica compartilhada com `ms-offers-v1`:** o `RuleEvaluator` precisa
   bater com o engine de runtime. Ideal extrair `model.dsl` para uma lib comum —
   senão a tabela-verdade aprovada no preview pode divergir de produção.

---

## Decisão de DSL: 4 operadores

`REQUIRES`, `EXCLUDES`, `ONE_OF`, `MIN_SELECTION`. `CONDITIONAL` foi removido por
redundância com `REQUIRES` + `NONE_SELECTED` (menos ambiguidade para a LLM).
Reintroduza só com evidência empírica (golden-set falhando).
