# ms-ai-offer-rule-resolver-v1

Microsserviço que **compila regras de oferta escritas em linguagem natural (PT-BR)**
para a **DSL do catálogo** (modelo do PDF), validada de forma determinística,
simulada em sandbox (tabela-verdade) e revisada por uma juíza semântica via LLM.

- **Spring Boot 4.1.0** · **Spring AI 2.0.0** · **Java 17**
- **Provider:** Azure OpenAI, **modelo único `gpt-4o`** (tradutor e juíza)
- **Arquitetura:** camadas MVC (`controller` → `service` → `repository`)

> Princípio: **a LLM é um compilador, não a autoridade final.** Toda saída passa
> pelo validador determinístico; a juíza compara *comportamento* (a tabela-verdade),
> não JSON; nas primeiras semanas, **tudo vai a revisão humana**.

---

## Modelo de domínio (PDF)

### Oferta = árvore recursiva (entra como JSON pelo `OfferParser`)

`Root → Group → Group → Product`, profundidade arbitrária. Cada agrupamento tem
cardinalidade de **seleção** `selectMin..selectMax` (quantos filhos escolher).
Produtos têm identidade própria e quantidade `qtyMin..qtyMax` (metadado). Arestas
`related` (compre-junto) ficam **fora do bundle** e são ignoradas pelo sandbox.

Modelo canônico interno: `OfferModel(OfferNode root, List<RelatedEdge> related)`
(pacote `model.offer`). A oferta SEMPRE chega como JSON e é convertida pelo
`OfferJsonParser` — trocar o formato do JSON = trocar só o parser.

### Regra = janelas de entrada/saída + tipo (codifica as 7 portas)

```
CompiledRule( input[inMin..inMax]  ── dispara ──►  output[outMin..outMax]  + type )
```
- **DISPARA** quando a contagem de itens de ENTRADA selecionados ∈ [inMin, inMax].
- **VALIDA** (quando disparada) a contagem de SAÍDA contra [outMin, outMax].
- `type = REQUIRES` (saída deve cair na janela) | `INCOMPATIBLE_WITH` (não pode).

As 7 portas do PDF são tuplas (input, inMin, inMax, output, outMin, outMax, type):

| Porta | input | in | output | out | type |
|---|---|---|---|---|---|
| NOT  | {A}   | 1..1 | {C} | 1..1 | INCOMPATIBLE_WITH |
| AND  | {A,B} | 2..2 | {C} | 1..1 | REQUIRES |
| NAND | {A,B} | 2..2 | {C} | 1..1 | INCOMPATIBLE_WITH |
| OR   | {A,B} | 1..2 | {C} | 1..1 | REQUIRES |
| NOR  | {A,B} | 1..2 | {C} | 1..1 | INCOMPATIBLE_WITH |
| XOR  | {A,B} | 1..1 | {C} | 1..1 | REQUIRES |
| XNOR | {A,B} | 1..1 | {C} | 1..1 | INCOMPATIBLE_WITH |

> NOT e XNOR têm a mesma tupla de janelas; o que os distingue é a **aridade do
> conjunto de entrada** (`{A}` vs `{A,B}`), que o `CompiledRule` carrega.
> A semântica vive num único lugar: `model.dsl.RuleEvaluator`.

---

## Arquitetura em camadas

```
HTTP ─► controller ─► service ─► repository ─► PostgreSQL
                         │
                         ├─ ChatModel (Azure gpt-4o)   ← tradutor e juíza
                         └─ RuleEvaluator (semântica determinística da DSL)
```

Fluxo (por regra): `parse JSON da oferta → traduz+valida (retry) → sandbox → juíza → score → auditoria`.

| Camada | Pacote | Responsabilidade |
|---|---|---|
| controller | `controller` | REST fino; delega ao service |
| service | `service` | orquestrador + etapas (context, translator, validator, sandbox, judge, scorer) |
| repository | `repository` | auditoria (`compilation_log`) |
| domínio | `model.dsl`, `model.offer`, `model.dto` | DSL, oferta em árvore, contratos |

---

## Como rodar

### Pré-requisito de build
Spring AI 2.0.0 + Spring Boot 4.1.0 no `~/.m2` (se você usa o Spring AI do fonte,
rode `./mvnw install -DskipTests` no repositório do Spring AI primeiro).

### Testes (sem credenciais, LLM mockada, H2)
```bash
mvn test
```
`RuleEvaluatorTest` prova as **7 portas**; `SandboxServiceTest` prova a enumeração
hierárquica; `RuleCompilationServiceIT` exercita o pipeline sobre a oferta "Bolota".

### Subir localmente
```bash
docker run --name offerrules -e POSTGRES_DB=offerrules -e POSTGRES_PASSWORD=postgres -p 5432:5432 -d postgres:16
export AZURE_OPENAI_ENDPOINT="https://SEU-RECURSO.openai.azure.com"
export AZURE_OPENAI_API_KEY="..."
export AZURE_OPENAI_DEPLOYMENT="gpt-4o"
mvn spring-boot:run
```

### Chamar a API (oferta em árvore + regra OR)
```bash
curl -s http://localhost:8080/api/v1/rules/compile -H 'Content-Type: application/json' -d '{
  "offerJson": { "root": { "id":"bolota","type":"ROOT","selectMin":2,"selectMax":2,"children":[
    {"id":"plano","type":"GROUP","selectMin":1,"selectMax":1,"children":[
      {"id":"20GB","type":"PRODUCT"},{"id":"30GB","type":"PRODUCT"}]},
    {"id":"aparelho","type":"GROUP","selectMin":1,"selectMax":1,"children":[
      {"id":"iphone-preto","type":"PRODUCT"},{"id":"iphone-branco","type":"PRODUCT"}]}
  ]}},
  "naturalLanguageRules": ["Se selecionei 20GB ou 30GB então devo selecionar Iphone 17 256GB Branco."],
  "locale": "pt-BR"
}'
```
Outros: `GET /api/v1/rules/schema` (JSON Schema da DSL), `GET /actuator/health`.

---

## O que NÃO está aqui (requisitos do PDF fora deste serviço)

Escopo deste MS = **compilar/validar/simular** as regras. Ficaram de fora (pedem
trabalho próprio, não bloqueiam o núcleo):
- **RF4 — conflito/sobreposição entre regras** (análise do conjunto de regras).
- **RF6 — versionamento da oferta** e **RF7 — fluxo de aprovação/disponibilização**.
- **RF3 — produtos `related`**: o modelo já os carrega (parseados, fora do bundle),
  mas não há lógica de cross-sell além disso.

---

## Pontos de atenção
1. **`strict-schema`** vem `false` (robusto). Ligue para `true` só com deployment
   gpt-4o ≥ 2024-08-06.
2. **Nomes de propriedade Azure** (`microsoft-foundry`, `deployment-name`):
   derivados do fonte 2.0.0; confirme na sua build.
3. **Semântica compartilhada com o engine de runtime:** o `RuleEvaluator` precisa
   bater com o executor das ofertas — ideal extrair `model.dsl` para uma lib comum,
   senão a tabela-verdade aprovada pode divergir de produção.
