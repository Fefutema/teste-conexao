package com.empresa.offerruleresolver.service;

import java.util.List;
import java.util.Map;

import com.empresa.offerruleresolver.model.dsl.RuleType;
import com.empresa.offerruleresolver.model.dto.CompileResponse;
import com.empresa.offerruleresolver.model.dto.RuleResult;
import com.empresa.offerruleresolver.model.dto.RuleStatus;
import com.empresa.offerruleresolver.repository.CompilationLogRepository;

import org.junit.jupiter.api.Test;

import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.model.Generation;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

/**
 * Pipeline integrado com a LLM MOCKADA (sem chamadas reais). Verifica a fiação
 * das camadas: parser → tradutor → validador → sandbox → juíza → scorer →
 * auditoria. Roda com {@code ./mvnw test} contra H2, sem credenciais.
 */
@SpringBootTest
class RuleCompilationServiceIT {

	private static final String TRANSLATOR_JSON = """
			{
			  "id": "phone-required",
			  "dslVersion": "v1",
			  "type": "MIN_SELECTION",
			  "antecedents": [ { "slotId": "phone", "match": "ANY_SELECTED", "optionIds": [] } ],
			  "consequents": [],
			  "params": { "min": 1, "max": null },
			  "userFacingMessage": "Você precisa escolher um celular."
			}
			""";

	private static final String JUDGE_JSON = """
			{ "equivalent": true, "confidence": 0.95, "discrepancies": [] }
			""";

	@MockitoBean
	private ChatModel chatModel;

	@Autowired
	private RuleCompilationService service;

	@Autowired
	private CompilationLogRepository logRepository;

	@Test
	void compilesRuleEndToEndAndAudits() {
		// 1ª chamada do modelo = tradutor; 2ª = juíza.
		when(this.chatModel.call(any(Prompt.class))).thenReturn(response(TRANSLATOR_JSON), response(JUDGE_JSON));

		CompileResponse response = this.service.compile(offer(), List.of("O celular é obrigatório."));

		assertThat(response.results()).hasSize(1);
		RuleResult result = response.results().get(0);
		assertThat(result.status()).isEqualTo(RuleStatus.NEEDS_REVIEW); // force-human-review=true
		assertThat(result.rule().type()).isEqualTo(RuleType.MIN_SELECTION);
		assertThat(result.confidence()).isEqualTo(0.95);
		assertThat(result.requiresHumanReview()).isTrue();
		assertThat(result.preview()).isNotEmpty();

		assertThat(this.logRepository.count()).isEqualTo(1);
	}

	private ChatResponse response(String content) {
		return new ChatResponse(List.of(new Generation(new AssistantMessage(content))));
	}

	private Map<String, Object> offer() {
		return Map.of(
				"offerId", "combo-test",
				"slots", List.of(
						Map.of("id", "phone", "minQty", 1, "maxQty", 1, "options",
								List.of(Map.of("id", "iphone-15", "label", "iPhone 15"),
										Map.of("id", "galaxy-s24", "label", "Galaxy S24"))),
						Map.of("id", "case", "minQty", 0, "maxQty", 1, "options",
								List.of(Map.of("id", "case-silicone", "label", "Silicone"))),
						Map.of("id", "streaming", "minQty", 0, "maxQty", 1, "options",
								List.of(Map.of("id", "netflix-12m", "label", "Netflix")))));
	}
}
