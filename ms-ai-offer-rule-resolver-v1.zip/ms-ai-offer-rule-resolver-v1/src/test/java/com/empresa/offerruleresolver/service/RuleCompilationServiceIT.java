package com.empresa.offerruleresolver.service;

import java.util.List;
import java.util.Map;

import com.empresa.offerruleresolver.model.dsl.RuleType;
import com.empresa.offerruleresolver.model.dto.CompileResponse;
import com.empresa.offerruleresolver.model.dto.RuleResult;
import com.empresa.offerruleresolver.model.dto.RuleStatus;
import com.empresa.offerruleresolver.repository.CompilationLogRepository;

import org.junit.jupiter.api.Test;

import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.model.Generation;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

/**
 * Pipeline integrado com a LLM MOCKADA (sem chamadas reais), sobre a oferta em
 * árvore "Bolota". Verifica a fiação: parser recursivo -> tradutor -> validador
 * -> sandbox hierárquico -> juíza -> scorer -> auditoria.
 */
@SpringBootTest
class RuleCompilationServiceIT {

	// Regra OR: se 20GB ou 30GB então iPhone Branco (in 1..2, out 1..1, REQUIRES)
	private static final String TRANSLATOR_JSON = """
			{
			  "id": "plan-or-requires-branco",
			  "type": "REQUIRES",
			  "input": ["20GB", "30GB"],
			  "inMin": 1, "inMax": 2,
			  "output": ["iphone-branco"],
			  "outMin": 1, "outMax": 1,
			  "userFacingMessage": "Com 20GB ou 30GB, o iPhone Branco é obrigatório."
			}
			""";

	private static final String JUDGE_JSON = """
			{ "equivalent": true, "confidence": 0.95, "discrepancies": [] }
			""";

	@MockitoBean
	private ChatModel chatModel;

	@Autowired
	private RuleCompilationService service;

	@Autowired
	private CompilationLogRepository logRepository;

	@Test
	void compilesRuleEndToEndAndAudits() {
		when(this.chatModel.call(any(Prompt.class))).thenReturn(response(TRANSLATOR_JSON), response(JUDGE_JSON));

		CompileResponse response = this.service.compile(offer(),
				List.of("Se selecionei 20GB ou 30GB então devo selecionar Iphone 17 256GB Branco."));

		assertThat(response.results()).hasSize(1);
		RuleResult result = response.results().get(0);
		assertThat(result.status()).isEqualTo(RuleStatus.NEEDS_REVIEW); // force-human-review=true
		assertThat(result.rule().type()).isEqualTo(RuleType.REQUIRES);
		assertThat(result.rule().input()).containsExactlyInAnyOrder("20GB", "30GB");
		assertThat(result.confidence()).isEqualTo(0.95);
		assertThat(result.preview()).isNotEmpty();

		assertThat(this.logRepository.count()).isEqualTo(1);
	}

	private ChatResponse response(String content) {
		return new ChatResponse(List.of(new Generation(new AssistantMessage(content))));
	}

	/** Oferta "Bolota" em árvore: plano (1..1 de 20GB/30GB) + aparelho (1..1 de preto/branco). */
	private Map<String, Object> offer() {
		return Map.of("root", Map.of(
				"id", "bolota", "type", "ROOT", "selectMin", 2, "selectMax", 2,
				"children", List.of(
						Map.of("id", "plano", "type", "GROUP", "selectMin", 1, "selectMax", 1,
								"children", List.of(
										Map.of("id", "20GB", "type", "PRODUCT"),
										Map.of("id", "30GB", "type", "PRODUCT"))),
						Map.of("id", "aparelho", "type", "GROUP", "selectMin", 1, "selectMax", 1,
								"children", List.of(
										Map.of("id", "iphone-preto", "type", "PRODUCT"),
										Map.of("id", "iphone-branco", "type", "PRODUCT"))))));
	}
}
