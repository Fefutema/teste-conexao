package com.empresa.offerruleresolver.service;

import java.util.List;

import com.empresa.offerruleresolver.config.CompilerProperties;
import com.empresa.offerruleresolver.model.dsl.CompiledRule;
import com.empresa.offerruleresolver.model.dsl.MatchMode;
import com.empresa.offerruleresolver.model.dsl.RuleEvaluator;
import com.empresa.offerruleresolver.model.dsl.RuleParams;
import com.empresa.offerruleresolver.model.dsl.RuleType;
import com.empresa.offerruleresolver.model.dsl.SlotRef;
import com.empresa.offerruleresolver.model.dto.SandboxScenario;
import com.empresa.offerruleresolver.model.offer.CatalogSlot;
import com.empresa.offerruleresolver.model.offer.OfferCatalog;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class SandboxServiceTest {

	private final CompilerProperties properties = new CompilerProperties(
			new CompilerProperties.Translator(0.1, 2, false),
			new CompilerProperties.Judge(0.0, false),
			new CompilerProperties.Confidence(0.9, 0.6, true),
			new CompilerProperties.Sandbox(64));

	private final SandboxService sandbox = new SandboxService(new RuleEvaluator(), properties);

	@Test
	void generatesTwoToTheNScenarios() {
		OfferCatalog catalog = new OfferCatalog("o", List.of(
				new CatalogSlot("phone", 1, 1, List.of("iphone-15")),
				new CatalogSlot("case", 0, 1, List.of("case-silicone")),
				new CatalogSlot("streaming", 0, 1, List.of("netflix-12m"))));

		CompiledRule rule = new CompiledRule("phone-required", "v1", RuleType.MIN_SELECTION,
				List.of(new SlotRef("phone", MatchMode.ANY_SELECTED, List.of())), List.of(),
				new RuleParams(1, null), "msg");

		List<SandboxScenario> table = sandbox.truthTable(rule, catalog);

		assertThat(table).hasSize(8); // 2^3
		assertThat(table).anyMatch(SandboxScenario::valid);   // satisfazível
		assertThat(sandbox.isUnsatisfiable(table)).isFalse();
	}

	@Test
	void detectsUnsatisfiableRule() {
		// slot sem opções => nunca é preenchido => MIN_SELECTION min=1 nunca é satisfeito
		OfferCatalog catalog = new OfferCatalog("o", List.of(
				new CatalogSlot("phone", 1, 1, List.of())));

		CompiledRule rule = new CompiledRule("phone-required", "v1", RuleType.MIN_SELECTION,
				List.of(new SlotRef("phone", MatchMode.ANY_SELECTED, List.of())), List.of(),
				new RuleParams(1, null), "msg");

		List<SandboxScenario> table = sandbox.truthTable(rule, catalog);

		assertThat(sandbox.isUnsatisfiable(table)).isTrue();
	}
}
