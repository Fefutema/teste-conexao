package com.empresa.offerruleresolver.service;

import java.util.List;
import java.util.Set;

import com.empresa.offerruleresolver.config.CompilerProperties;
import com.empresa.offerruleresolver.model.dsl.CompiledRule;
import com.empresa.offerruleresolver.model.dsl.RuleEvaluator;
import com.empresa.offerruleresolver.model.dsl.RuleType;
import com.empresa.offerruleresolver.model.dto.SandboxScenario;
import com.empresa.offerruleresolver.model.dto.TruthTable;
import com.empresa.offerruleresolver.model.offer.NodeType;
import com.empresa.offerruleresolver.model.offer.OfferModel;
import com.empresa.offerruleresolver.model.offer.OfferNode;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * A enumeração hierárquica respeita a cardinalidade de seleção e é CONSERVADORA
 * sob truncamento (não conclui insatisfazibilidade de tabela parcial).
 */
class SandboxServiceTest {

	private static OfferNode product(String id) {
		return new OfferNode(id, NodeType.PRODUCT, 0, 0, 1, 1, List.of());
	}

	private SandboxService sandbox(int maxScenarios) {
		CompilerProperties props = new CompilerProperties(new CompilerProperties.Translator(0.1, 2, false),
				new CompilerProperties.Judge(0.0, false), new CompilerProperties.Confidence(0.9, 0.6, true),
				new CompilerProperties.Sandbox(maxScenarios));
		return new SandboxService(new RuleEvaluator(), props);
	}

	@Test
	void enumeratesRespectingGroupCardinality() {
		OfferModel offer = new OfferModel(
				new OfferNode("root", NodeType.ROOT, 1, 1, 0, 0, List.of(product("a"), product("b"))), List.of());
		CompiledRule rule = new CompiledRule("r", RuleType.REQUIRES, List.of("a"), 1, 1, List.of("b"), 1, 1, "m");

		TruthTable table = sandbox(64).truthTable(rule, offer);

		assertThat(table.truncated()).isFalse();
		assertThat(table.scenarios()).extracting(SandboxScenario::selectedProducts)
				.containsExactlyInAnyOrder(Set.of("a"), Set.of("b"));
		assertThat(sandbox(64).isUnsatisfiable(table)).isFalse();
	}

	@Test
	void detectsUnsatisfiableRuleOnCompleteTable() {
		OfferModel offer = new OfferModel(
				new OfferNode("root", NodeType.ROOT, 1, 1, 0, 0, List.of(product("a"))), List.of());
		CompiledRule rule = new CompiledRule("r", RuleType.REQUIRES, List.of("a"), 1, 1, List.of("a"), 2, 2, "m");

		SandboxService s = sandbox(64);
		TruthTable table = s.truthTable(rule, offer);

		assertThat(table.truncated()).isFalse();
		assertThat(s.isUnsatisfiable(table)).isTrue();
	}

	@Test
	void truncatedTableIsNeverDeclaredUnsatisfiable() {
		// cap = 1 força truncamento; mesmo sem cenário válido, NÃO conclui insatisfazível
		OfferModel offer = new OfferModel(
				new OfferNode("root", NodeType.ROOT, 1, 1, 0, 0, List.of(product("a"), product("b"))), List.of());
		CompiledRule rule = new CompiledRule("r", RuleType.REQUIRES, List.of("a"), 1, 1, List.of("a"), 2, 2, "m");

		SandboxService s = sandbox(1);
		TruthTable table = s.truthTable(rule, offer);

		assertThat(table.truncated()).isTrue();
		assertThat(s.isUnsatisfiable(table)).isFalse(); // conservador
	}
}
