package com.empresa.offerruleresolver.model.dsl;

import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * A semântica das 7 portas lógicas do PDF, codificadas como tuplas de janelas.
 * Este é o teste-chave: prova que o novo evaluator expressa AS 7 portas —
 * inclusive NOT/XOR/XNOR (entrada 1..1 = "exatamente um"), que o modelo antigo
 * NÃO conseguia. Entrada A="a", B="b"; saída C="c".
 */
class RuleEvaluatorTest {

	private final RuleEvaluator evaluator = new RuleEvaluator();

	private CompiledRule gate(RuleType type, List<String> in, int inMin, int inMax, List<String> out, int outMin,
			int outMax) {
		return new CompiledRule("g", type, in, inMin, inMax, out, outMin, outMax, "msg");
	}

	private boolean sat(CompiledRule rule, String... selected) {
		return this.evaluator.isSatisfied(new ConfigState(Set.of(selected)), rule);
	}

	private static final List<String> AB = List.of("a", "b");
	private static final List<String> A = List.of("a");
	private static final List<String> C = List.of("c");

	@Test
	void andGate() { // in 2..2, out 1..1, REQUIRES
		CompiledRule r = gate(RuleType.REQUIRES, AB, 2, 2, C, 1, 1);
		assertThat(sat(r, "a")).isTrue();            // não dispara (in=1)
		assertThat(sat(r, "a", "b")).isFalse();      // dispara, mas C ausente
		assertThat(sat(r, "a", "b", "c")).isTrue();  // dispara e C presente
	}

	@Test
	void nandGate() { // in 2..2, out 1..1, INCOMPATIBLE_WITH
		CompiledRule r = gate(RuleType.INCOMPATIBLE_WITH, AB, 2, 2, C, 1, 1);
		assertThat(sat(r, "a", "b")).isTrue();       // dispara e C ausente => OK
		assertThat(sat(r, "a", "b", "c")).isFalse(); // dispara e C presente => proibido
	}

	@Test
	void orGate() { // in 1..2, out 1..1, REQUIRES
		CompiledRule r = gate(RuleType.REQUIRES, AB, 1, 2, C, 1, 1);
		assertThat(sat(r)).isTrue();                 // não dispara (in=0)
		assertThat(sat(r, "a")).isFalse();           // dispara (in=1), C ausente
		assertThat(sat(r, "a", "c")).isTrue();       // dispara e C presente
		assertThat(sat(r, "a", "b", "c")).isTrue();  // dispara (in=2) e C presente
	}

	@Test
	void norGate() { // in 1..2, out 1..1, INCOMPATIBLE_WITH
		CompiledRule r = gate(RuleType.INCOMPATIBLE_WITH, AB, 1, 2, C, 1, 1);
		assertThat(sat(r, "a")).isTrue();            // dispara, C ausente => OK
		assertThat(sat(r, "a", "c")).isFalse();      // dispara, C presente => proibido
	}

	@Test
	void xorGate_previouslyImpossible() { // in 1..1, out 1..1, REQUIRES
		CompiledRule r = gate(RuleType.REQUIRES, AB, 1, 1, C, 1, 1);
		assertThat(sat(r, "a")).isFalse();           // exatamente 1 dispara; C ausente
		assertThat(sat(r, "a", "c")).isTrue();       // dispara e C presente
		assertThat(sat(r, "a", "b")).isTrue();       // in=2 NÃO dispara (vacuamente OK)
		assertThat(sat(r, "a", "b", "c")).isTrue();  // in=2 NÃO dispara
	}

	@Test
	void xnorGate_previouslyImpossible() { // in 1..1, out 1..1, INCOMPATIBLE_WITH
		CompiledRule r = gate(RuleType.INCOMPATIBLE_WITH, AB, 1, 1, C, 1, 1);
		assertThat(sat(r, "a")).isTrue();            // exatamente 1 dispara; C ausente => OK
		assertThat(sat(r, "a", "c")).isFalse();      // dispara e C presente => proibido
		assertThat(sat(r, "a", "b")).isTrue();       // in=2 NÃO dispara
	}

	@Test
	void notGate_unaryInput() { // input {a} (aridade 1), in 1..1, out 1..1, INCOMPATIBLE_WITH
		CompiledRule r = gate(RuleType.INCOMPATIBLE_WITH, A, 1, 1, C, 1, 1);
		assertThat(sat(r, "a")).isTrue();            // A dispara; C ausente => OK
		assertThat(sat(r, "a", "c")).isFalse();      // A dispara; C presente => proibido
		assertThat(sat(r, "c")).isTrue();            // A ausente => não dispara
	}

	@Test
	void notAndXnorAreDistinctByInputArity() {
		// mesma tupla de janelas (1,1,1,1,INCOMPATIBLE_WITH); o que muda é o conjunto de entrada
		CompiledRule not = gate(RuleType.INCOMPATIBLE_WITH, A, 1, 1, C, 1, 1);
		CompiledRule xnor = gate(RuleType.INCOMPATIBLE_WITH, AB, 1, 1, C, 1, 1);
		// com {a,b,c}: NOT dispara (conta só 'a' => in=1) e proíbe c => falso;
		//              XNOR não dispara (in=2) => verdadeiro. Comportamentos divergem.
		assertThat(sat(not, "a", "b", "c")).isFalse();
		assertThat(sat(xnor, "a", "b", "c")).isTrue();
	}
}
