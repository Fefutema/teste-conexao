package com.empresa.offerruleresolver.model.dsl;

import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Semântica dos operadores da DSL — o contrato que precisa bater com o engine de
 * runtime. Testes puros, sem Spring.
 */
class RuleEvaluatorTest {

	private final RuleEvaluator evaluator = new RuleEvaluator();

	private ConfigState state(Map<String, List<String>> selections) {
		return new ConfigState(selections);
	}

	@Test
	void minSelectionRequiresAtLeastMin() {
		CompiledRule rule = new CompiledRule("phone-required", "v1", RuleType.MIN_SELECTION,
				List.of(new SlotRef("phone", MatchMode.ANY_SELECTED, List.of())), List.of(),
				new RuleParams(1, null), "msg");

		assertThat(evaluator.isSatisfied(state(Map.of("phone", List.of("iphone-15"))), rule)).isTrue();
		assertThat(evaluator.isSatisfied(state(Map.of()), rule)).isFalse();
	}

	@Test
	void requiresIsVacuouslyTrueWhenAntecedentNotMet() {
		CompiledRule rule = new CompiledRule("no-case-requires-streaming", "v1", RuleType.REQUIRES,
				List.of(new SlotRef("case", MatchMode.NONE_SELECTED, List.of())),
				List.of(new SlotRef("streaming", MatchMode.ANY_SELECTED, List.of())), null, "msg");

		// case selecionado => antecedente (NONE_SELECTED) falso => regra satisfeita (vacuamente)
		assertThat(evaluator.isSatisfied(state(Map.of("case", List.of("case-silicone"))), rule)).isTrue();
		// case vazio + streaming vazio => antecedente verdadeiro, consequente falso => NÃO satisfeita
		assertThat(evaluator.isSatisfied(state(Map.of()), rule)).isFalse();
		// case vazio + streaming selecionado => satisfeita
		assertThat(evaluator.isSatisfied(state(Map.of("streaming", List.of("netflix-12m"))), rule)).isTrue();
	}

	@Test
	void excludesForbidsConsequentWhenAntecedentMet() {
		CompiledRule rule = new CompiledRule("case-excludes-streaming", "v1", RuleType.EXCLUDES,
				List.of(new SlotRef("case", MatchMode.ANY_SELECTED, List.of())),
				List.of(new SlotRef("streaming", MatchMode.ANY_SELECTED, List.of())), null, "msg");

		assertThat(evaluator.isSatisfied(
				state(Map.of("case", List.of("case-silicone"), "streaming", List.of("netflix-12m"))), rule)).isFalse();
		assertThat(evaluator.isSatisfied(state(Map.of("case", List.of("case-silicone"))), rule)).isTrue();
	}

	@Test
	void oneOfRequiresExactlyOne() {
		CompiledRule rule = new CompiledRule("streaming-one-of", "v1", RuleType.ONE_OF,
				List.of(new SlotRef("streaming", MatchMode.SPECIFIC_OPTIONS, List.of("netflix-12m", "hbo-12m"))),
				List.of(), null, "msg");

		assertThat(evaluator.isSatisfied(state(Map.of("streaming", List.of("netflix-12m"))), rule)).isTrue();
		assertThat(evaluator.isSatisfied(state(Map.of()), rule)).isFalse();
		assertThat(evaluator.isSatisfied(state(Map.of("streaming", List.of("netflix-12m", "hbo-12m"))), rule))
				.isFalse();
	}
}
