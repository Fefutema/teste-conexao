package com.empresa.offerruleresolver.service;

import java.util.List;

import com.empresa.offerruleresolver.model.dsl.CompiledRule;
import com.empresa.offerruleresolver.model.dsl.RuleType;
import com.empresa.offerruleresolver.model.dto.ValidationError;
import com.empresa.offerruleresolver.model.dto.ValidationResult;
import com.empresa.offerruleresolver.model.offer.NodeType;
import com.empresa.offerruleresolver.model.offer.OfferModel;
import com.empresa.offerruleresolver.model.offer.OfferNode;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * O guardrail determinístico sobre o novo modelo (produtos + janelas).
 */
class RuleValidatorTest {

	private final RuleValidator validator = new RuleValidator();

	private final OfferModel offer = new OfferModel(new OfferNode("root", NodeType.ROOT, 1, 1, 0, 0,
			List.of(product("a"), product("b"))), List.of());

	private static OfferNode product(String id) {
		return new OfferNode(id, NodeType.PRODUCT, 0, 0, 1, 1, List.of());
	}

	private List<String> codes(ValidationResult result) {
		return result.errors().stream().map(ValidationError::code).toList();
	}

	private CompiledRule rule(List<String> in, int inMin, int inMax, List<String> out, int outMin, int outMax,
			String msg) {
		return new CompiledRule("r", RuleType.REQUIRES, in, inMin, inMax, out, outMin, outMax, msg);
	}

	@Test
	void acceptsValidRule() {
		assertThat(validator.validate(rule(List.of("a"), 1, 1, List.of("b"), 1, 1, "ok"), offer).valid()).isTrue();
	}

	@Test
	void rejectsUnknownProduct() {
		assertThat(codes(validator.validate(rule(List.of("x"), 1, 1, List.of("b"), 1, 1, "m"), offer)))
				.contains("UNKNOWN_PRODUCT");
	}

	@Test
	void rejectsEmptyInput() {
		assertThat(codes(validator.validate(rule(List.of(), 0, 0, List.of("b"), 1, 1, "m"), offer)))
				.contains("EMPTY_INPUT");
	}

	@Test
	void rejectsInvalidWindow() {
		assertThat(codes(validator.validate(rule(List.of("a"), 2, 1, List.of("b"), 1, 1, "m"), offer)))
				.contains("INVALID_INPUT_WINDOW");
	}

	@Test
	void rejectsBlankMessage() {
		assertThat(codes(validator.validate(rule(List.of("a"), 1, 1, List.of("b"), 1, 1, "  "), offer)))
				.contains("MISSING_MESSAGE");
	}

	@Test
	void rejectsInputWindowMinZero() {
		// inMin=0 faria a regra disparar sem gatilho selecionado (efeito incondicional)
		assertThat(codes(validator.validate(rule(List.of("a"), 0, 1, List.of("b"), 1, 1, "m"), offer)))
				.contains("INVALID_INPUT_WINDOW");
	}

	@Test
	void rejectsInputOutputOverlap() {
		assertThat(codes(validator.validate(rule(List.of("a"), 1, 1, List.of("a"), 1, 1, "m"), offer)))
				.contains("INPUT_OUTPUT_OVERLAP");
	}
}
