package com.empresa.offerruleresolver.service;

import java.util.List;

import com.empresa.offerruleresolver.model.dsl.CompiledRule;
import com.empresa.offerruleresolver.model.dsl.MatchMode;
import com.empresa.offerruleresolver.model.dsl.RuleParams;
import com.empresa.offerruleresolver.model.dsl.RuleType;
import com.empresa.offerruleresolver.model.dsl.SlotRef;
import com.empresa.offerruleresolver.model.dto.ValidationError;
import com.empresa.offerruleresolver.model.dto.ValidationResult;
import com.empresa.offerruleresolver.model.offer.CatalogSlot;
import com.empresa.offerruleresolver.model.offer.OfferCatalog;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * O guardrail determinístico. Cobertura dos códigos de erro principais.
 */
class RuleValidatorTest {

	private final RuleValidator validator = new RuleValidator();

	private final OfferCatalog catalog = new OfferCatalog("combo-test", List.of(
			new CatalogSlot("phone", 1, 1, List.of("iphone-15", "galaxy-s24")),
			new CatalogSlot("case", 0, 1, List.of("case-silicone")),
			new CatalogSlot("streaming", 0, 1, List.of("netflix-12m"))));

	private List<String> codes(ValidationResult result) {
		return result.errors().stream().map(ValidationError::code).toList();
	}

	@Test
	void acceptsValidRule() {
		CompiledRule rule = new CompiledRule("phone-required", "v1", RuleType.MIN_SELECTION,
				List.of(new SlotRef("phone", MatchMode.ANY_SELECTED, List.of())), List.of(),
				new RuleParams(1, null), "Escolha um celular.");

		assertThat(validator.validate(rule, catalog).valid()).isTrue();
	}

	@Test
	void rejectsUnknownSlot() {
		CompiledRule rule = new CompiledRule("bad", "v1", RuleType.MIN_SELECTION,
				List.of(new SlotRef("celular_smartphone", MatchMode.ANY_SELECTED, List.of())), List.of(),
				new RuleParams(1, null), "msg");

		assertThat(codes(validator.validate(rule, catalog))).contains("UNKNOWN_SLOT");
	}

	@Test
	void rejectsOptionNotInSlot() {
		CompiledRule rule = new CompiledRule("bad", "v1", RuleType.REQUIRES,
				List.of(new SlotRef("phone", MatchMode.SPECIFIC_OPTIONS, List.of("nao-existe"))),
				List.of(new SlotRef("case", MatchMode.ANY_SELECTED, List.of())), null, "msg");

		assertThat(codes(validator.validate(rule, catalog))).contains("OPTION_NOT_IN_SLOT");
	}

	@Test
	void rejectsMinSelectionWithoutMin() {
		CompiledRule rule = new CompiledRule("bad", "v1", RuleType.MIN_SELECTION,
				List.of(new SlotRef("phone", MatchMode.ANY_SELECTED, List.of())), List.of(),
				new RuleParams(null, null), "msg");

		assertThat(codes(validator.validate(rule, catalog))).contains("MISSING_PARAM");
	}

	@Test
	void rejectsBlankMessage() {
		CompiledRule rule = new CompiledRule("phone-required", "v1", RuleType.MIN_SELECTION,
				List.of(new SlotRef("phone", MatchMode.ANY_SELECTED, List.of())), List.of(),
				new RuleParams(1, null), "  ");

		assertThat(codes(validator.validate(rule, catalog))).contains("MISSING_MESSAGE");
	}
}
