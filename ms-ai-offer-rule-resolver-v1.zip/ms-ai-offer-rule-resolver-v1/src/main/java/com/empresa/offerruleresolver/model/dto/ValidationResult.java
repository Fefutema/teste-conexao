package com.empresa.offerruleresolver.model.dto;

import java.util.List;

/**
 * Resultado da validação determinística: válido ou uma lista de erros.
 */
public record ValidationResult(boolean valid, List<ValidationError> errors) {

	public static ValidationResult ok() {
		return new ValidationResult(true, List.of());
	}

	public static ValidationResult of(List<ValidationError> errors) {
		return new ValidationResult(errors.isEmpty(), errors);
	}
}
