package com.empresa.offerruleresolver.service;

import java.util.List;

import com.empresa.offerruleresolver.config.CompilerProperties;
import com.empresa.offerruleresolver.model.dsl.CompiledRule;
import com.empresa.offerruleresolver.model.dto.JudgeVerdict;
import com.empresa.offerruleresolver.model.dto.RuleResult;
import com.empresa.offerruleresolver.model.dto.RuleStatus;
import com.empresa.offerruleresolver.model.dto.SandboxScenario;

import org.springframework.stereotype.Service;

/**
 * Decide o destino final da regra a partir do veredito da juíza e dos limiares
 * configurados.
 *
 * <pre>
 *   confiança  &ge; auto-approve            → COMPILED     (a menos que force-human-review)
 *   review-threshold .. auto-approve       → NEEDS_REVIEW (draft)
 *   &lt; review-threshold ou não-equivalente → REJECTED
 * </pre>
 *
 * Nota: na Fase 1, {@code force-human-review=true} faz tudo virar
 * {@code NEEDS_REVIEW}. Na Fase 2, a confiança passa a vir da self-consistency
 * (concordância entre k amostras), sinal mais objetivo que o auto-reporte da LLM.
 */
@Service
public class ConfidenceScorer {

	private final CompilerProperties properties;

	public ConfidenceScorer(CompilerProperties properties) {
		this.properties = properties;
	}

	public RuleResult score(String originalText, CompiledRule rule, JudgeVerdict verdict,
			List<SandboxScenario> preview) {
		CompilerProperties.Confidence cfg = properties.confidence();
		double confidence = verdict.confidence();
		List<String> warnings = verdict.discrepanciesOrEmpty();

		if (!verdict.equivalent() || confidence < cfg.reviewThreshold()) {
			String reason = verdict.equivalent() ? "LOW_CONFIDENCE" : "NOT_EQUIVALENT";
			return new RuleResult(originalText, RuleStatus.REJECTED, rule, confidence, true, preview, warnings, reason);
		}

		boolean requiresHumanReview = cfg.forceHumanReview() || confidence < cfg.autoApproveThreshold();
		RuleStatus status = requiresHumanReview ? RuleStatus.NEEDS_REVIEW : RuleStatus.COMPILED;
		return new RuleResult(originalText, status, rule, confidence, requiresHumanReview, preview, warnings, null);
	}
}
