package com.empresa.offerruleresolver.model.dsl;

/**
 * Parâmetros numéricos de uma regra. Campos nulláveis: só {@code MIN_SELECTION}
 * usa {@code min}. Mantidos nulláveis (e não primitivos) para tolerar respostas
 * da LLM que omitem o objeto quando ele não se aplica.
 */
public record RuleParams(Integer min, Integer max) {

	public static RuleParams empty() {
		return new RuleParams(null, null);
	}
}
