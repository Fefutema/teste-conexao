package com.empresa.offerruleresolver.model.offer;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Modelo canônico interno da oferta. É o ÚNICO que a camada de service enxerga —
 * o formato externo do {@code offerJson} nunca vaza para dentro do pipeline.
 * Quando o formato externo mudar, troca-se apenas o {@link OfferParser}.
 */
public record OfferCatalog(String offerId, List<CatalogSlot> slots) {

	public Set<String> slotIds() {
		return slots.stream().map(CatalogSlot::id).collect(Collectors.toCollection(java.util.LinkedHashSet::new));
	}

	public Optional<CatalogSlot> slot(String id) {
		return slots.stream().filter(s -> s.id().equals(id)).findFirst();
	}
}
