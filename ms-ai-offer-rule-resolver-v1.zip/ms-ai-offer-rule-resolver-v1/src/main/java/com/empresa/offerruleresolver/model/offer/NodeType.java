package com.empresa.offerruleresolver.model.offer;

/**
 * Tipo de nó do grafo da oferta (PDF): Root/Group são agrupadores; Product é
 * folha selecionável.
 */
public enum NodeType {
	ROOT, GROUP, PRODUCT
}
