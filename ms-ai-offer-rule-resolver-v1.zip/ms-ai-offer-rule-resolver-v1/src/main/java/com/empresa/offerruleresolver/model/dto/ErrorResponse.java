package com.empresa.offerruleresolver.model.dto;

/**
 * Corpo padrão de erro da API (nível de requisição).
 *
 * @param error   código estável do erro
 * @param message descrição legível
 */
public record ErrorResponse(String error, String message) {
}
