package com.empresa.offerruleresolver.model.dto;

/**
 * Erro determinístico de validação de uma regra.
 *
 * @param code    código estável (ex.: {@code UNKNOWN_SLOT})
 * @param message descrição legível, também reinjetada no prompt de auto-correção
 */
public record ValidationError(String code, String message) {
}
