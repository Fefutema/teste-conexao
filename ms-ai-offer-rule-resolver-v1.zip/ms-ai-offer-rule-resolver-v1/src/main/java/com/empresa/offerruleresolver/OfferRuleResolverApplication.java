package com.empresa.offerruleresolver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

@SpringBootApplication
@ConfigurationPropertiesScan
public class OfferRuleResolverApplication {

	public static void main(String[] args) {
		SpringApplication.run(OfferRuleResolverApplication.class, args);
	}

}
