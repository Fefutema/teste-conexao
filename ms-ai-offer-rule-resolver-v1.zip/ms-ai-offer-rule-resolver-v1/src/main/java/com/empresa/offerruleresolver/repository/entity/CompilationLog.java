package com.empresa.offerruleresolver.repository.entity;

import java.time.Instant;
import java.util.UUID;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * Registro de auditoria de cada compilação (camada repository). Sempre marque a
 * origem ({@code source}) — nunca misture regra de IA com regra humana sem
 * marcação.
 */
@Entity
@Table(name = "compilation_log")
public class CompilationLog {

	@Id
	@GeneratedValue(strategy = GenerationType.UUID)
	private UUID id;

	private String offerId;

	@Column(length = 4000)
	private String originalText;

	private String ruleId;

	private String ruleType;

	@Column(length = 4000)
	private String compiledRule;

	private double confidence;

	private boolean requiresHumanReview;

	private String status;

	@Column(length = 4000)
	private String judgeVerdict;

	private String source;

	private Instant createdAt;

	protected CompilationLog() {
		// JPA
	}

	private CompilationLog(Builder builder) {
		this.offerId = builder.offerId;
		this.originalText = builder.originalText;
		this.ruleId = builder.ruleId;
		this.ruleType = builder.ruleType;
		this.compiledRule = builder.compiledRule;
		this.confidence = builder.confidence;
		this.requiresHumanReview = builder.requiresHumanReview;
		this.status = builder.status;
		this.judgeVerdict = builder.judgeVerdict;
		this.source = builder.source;
		this.createdAt = builder.createdAt;
	}

	public static Builder builder() {
		return new Builder();
	}

	public UUID getId() {
		return this.id;
	}

	public String getOfferId() {
		return this.offerId;
	}

	public String getOriginalText() {
		return this.originalText;
	}

	public String getRuleId() {
		return this.ruleId;
	}

	public String getRuleType() {
		return this.ruleType;
	}

	public String getCompiledRule() {
		return this.compiledRule;
	}

	public double getConfidence() {
		return this.confidence;
	}

	public boolean isRequiresHumanReview() {
		return this.requiresHumanReview;
	}

	public String getStatus() {
		return this.status;
	}

	public String getJudgeVerdict() {
		return this.judgeVerdict;
	}

	public String getSource() {
		return this.source;
	}

	public Instant getCreatedAt() {
		return this.createdAt;
	}

	public static final class Builder {

		private String offerId;

		private String originalText;

		private String ruleId;

		private String ruleType;

		private String compiledRule;

		private double confidence;

		private boolean requiresHumanReview;

		private String status;

		private String judgeVerdict;

		private String source;

		private Instant createdAt;

		public Builder offerId(String offerId) {
			this.offerId = offerId;
			return this;
		}

		public Builder originalText(String originalText) {
			this.originalText = originalText;
			return this;
		}

		public Builder ruleId(String ruleId) {
			this.ruleId = ruleId;
			return this;
		}

		public Builder ruleType(String ruleType) {
			this.ruleType = ruleType;
			return this;
		}

		public Builder compiledRule(String compiledRule) {
			this.compiledRule = compiledRule;
			return this;
		}

		public Builder confidence(double confidence) {
			this.confidence = confidence;
			return this;
		}

		public Builder requiresHumanReview(boolean requiresHumanReview) {
			this.requiresHumanReview = requiresHumanReview;
			return this;
		}

		public Builder status(String status) {
			this.status = status;
			return this;
		}

		public Builder judgeVerdict(String judgeVerdict) {
			this.judgeVerdict = judgeVerdict;
			return this;
		}

		public Builder source(String source) {
			this.source = source;
			return this;
		}

		public Builder createdAt(Instant createdAt) {
			this.createdAt = createdAt;
			return this;
		}

		public CompilationLog build() {
			return new CompilationLog(this);
		}
	}
}
