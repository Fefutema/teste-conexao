package com.empresa.offerruleresolver.model.dto;

/**
 * Destino final de uma regra compilada.
 */
public enum RuleStatus {

	/** Confiança alta e auto-aprovação habilitada: pode salvar direto. */
	COMPILED,

	/** Válida, mas exige revisão humana (draft). */
	NEEDS_REVIEW,

	/** Não pôde ser compilada de forma confiável; devolvida com motivo. */
	REJECTED
}
