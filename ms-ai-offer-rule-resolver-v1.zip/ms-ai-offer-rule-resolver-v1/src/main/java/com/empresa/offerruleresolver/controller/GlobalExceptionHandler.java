package com.empresa.offerruleresolver.controller;

import com.empresa.offerruleresolver.exception.OfferParseException;
import com.empresa.offerruleresolver.model.dto.ErrorResponse;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * Mapeia exceções de nível de requisição para respostas HTTP estruturadas.
 * (Rejeições por regra NÃO passam por aqui: viram {@code RuleStatus.REJECTED} no
 * corpo 200.)
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(OfferParseException.class)
	public ResponseEntity<ErrorResponse> handleOfferParse(OfferParseException ex) {
		return ResponseEntity.unprocessableEntity()
				.body(new ErrorResponse("INVALID_OFFER", ex.getMessage()));
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<ErrorResponse> handleValidation(MethodArgumentNotValidException ex) {
		String detail = ex.getBindingResult().getFieldErrors().stream()
				.findFirst()
				.map(fe -> fe.getField() + ": " + fe.getDefaultMessage())
				.orElse("Requisição inválida.");
		return ResponseEntity.badRequest().body(new ErrorResponse("INVALID_REQUEST", detail));
	}
}
