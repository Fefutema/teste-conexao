package com.empresa.offerruleresolver.service;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.util.stream.Collectors;

import com.empresa.offerruleresolver.model.dto.TranslationContext;
import com.empresa.offerruleresolver.model.offer.OfferCatalog;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

/**
 * Prepara todo o contexto que vai para o prompt da LLM tradutora. Injetar os IDs
 * VÁLIDOS reduz alucinação de slotId/optionId em ordens de magnitude.
 *
 * <p>O golden-set e o glossário são carregados como TEXTO BRUTO e embutidos no
 * prompt como few-shot — sem parser de YAML (simplicidade; a LLM lê YAML bem).
 */
@Service
public class ContextBuilder {

	private final String fewShotExamples;

	private final String glossary;

	public ContextBuilder(@Value("classpath:eval/golden-set.yaml") Resource goldenSet,
			@Value("classpath:eval/glossary.yaml") Resource glossary) {
		this.fewShotExamples = read(goldenSet);
		this.glossary = read(glossary);
	}

	public TranslationContext build(OfferCatalog catalog) {
		String slotsEnum = String.join(", ", catalog.slotIds());

		String optionsEnum = catalog.slots().stream()
				.map(slot -> "- " + slot.id() + ": " + slot.optionIds())
				.collect(Collectors.joining("\n"));

		return new TranslationContext(slotsEnum, optionsEnum, this.fewShotExamples, this.glossary);
	}

	private String read(Resource resource) {
		try {
			return resource.getContentAsString(StandardCharsets.UTF_8);
		}
		catch (IOException ex) {
			throw new UncheckedIOException("Falha ao ler recurso: " + resource.getDescription(), ex);
		}
	}
}
