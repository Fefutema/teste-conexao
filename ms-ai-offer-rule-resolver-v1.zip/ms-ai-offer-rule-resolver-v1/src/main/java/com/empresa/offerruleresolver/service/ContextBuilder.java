package com.empresa.offerruleresolver.service;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;

import com.empresa.offerruleresolver.model.dto.TranslationContext;
import com.empresa.offerruleresolver.model.offer.OfferModel;
import com.empresa.offerruleresolver.model.offer.OfferNode;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

/**
 * Prepara o contexto do prompt da LLM tradutora. Injetar os productIds VÁLIDOS e
 * a estrutura em árvore reduz alucinação de ids. Golden-set e glossário são
 * carregados como texto bruto (sem parser YAML; a LLM lê bem).
 */
@Service
public class ContextBuilder {

	private final String fewShotExamples;

	private final String glossary;

	public ContextBuilder(@Value("classpath:eval/golden-set.yaml") Resource goldenSet,
			@Value("classpath:eval/glossary.yaml") Resource glossary) {
		this.fewShotExamples = read(goldenSet);
		this.glossary = read(glossary);
	}

	public TranslationContext build(OfferModel offer) {
		String productsEnum = String.join(", ", offer.allProductIds());
		String structure = renderTree(offer.root(), 0, new StringBuilder()).toString();
		return new TranslationContext(productsEnum, structure, this.fewShotExamples, this.glossary);
	}

	private StringBuilder renderTree(OfferNode node, int depth, StringBuilder sb) {
		sb.append("  ".repeat(depth)).append("- ").append(node.id()).append(" [").append(node.type()).append("]");
		if (!node.isProduct()) {
			sb.append(" seleciona ").append(node.selectMin()).append("..").append(node.selectMax());
		}
		sb.append("\n");
		node.childrenOrEmpty().forEach(child -> renderTree(child, depth + 1, sb));
		return sb;
	}

	private String read(Resource resource) {
		try {
			return resource.getContentAsString(StandardCharsets.UTF_8);
		}
		catch (IOException ex) {
			throw new UncheckedIOException("Falha ao ler recurso: " + resource.getDescription(), ex);
		}
	}
}
