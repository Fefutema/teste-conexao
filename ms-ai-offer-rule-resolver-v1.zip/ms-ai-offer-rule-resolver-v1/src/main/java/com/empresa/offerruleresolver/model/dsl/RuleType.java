package com.empresa.offerruleresolver.model.dsl;

/**
 * Operadores da DSL v1. Conjunto FECHADO e pequeno de propósito: menos
 * operadores = menos ambiguidade para a LLM = mais acurácia.
 *
 * <p>{@code CONDITIONAL} foi deliberadamente omitido por ser redundante com
 * {@code REQUIRES} + {@link MatchMode#NONE_SELECTED}. Só adicione um novo
 * operador com evidência empírica (golden-set falhando).
 */
public enum RuleType {

	/** Se os antecedentes estão satisfeitos, os consequentes também devem estar. */
	REQUIRES,

	/** Se os antecedentes estão satisfeitos, os consequentes NÃO podem estar. */
	EXCLUDES,

	/** Exatamente 1 das opções referenciadas nos antecedentes deve estar selecionada. */
	ONE_OF,

	/** Pelo menos {@code params.min} itens entre os antecedentes devem estar selecionados. */
	MIN_SELECTION
}
