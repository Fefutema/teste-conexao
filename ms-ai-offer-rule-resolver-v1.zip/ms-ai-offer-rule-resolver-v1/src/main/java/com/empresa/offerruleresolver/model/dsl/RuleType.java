package com.empresa.offerruleresolver.model.dsl;

/**
 * Polaridade da regra (nó Rule do catálogo). Combinada com as janelas de
 * cardinalidade de ENTRADA e SAÍDA, codifica todas as portas lógicas do PDF
 * (NOT, AND, NAND, OR, NOR, XOR, XNOR).
 */
public enum RuleType {

	/** Quando disparada, a SAÍDA deve cair na janela [outMin, outMax] (itens podem/devem existir). */
	REQUIRES,

	/** Quando disparada, a SAÍDA NÃO pode cair na janela [outMin, outMax] (itens não podem existir). */
	INCOMPATIBLE_WITH
}
