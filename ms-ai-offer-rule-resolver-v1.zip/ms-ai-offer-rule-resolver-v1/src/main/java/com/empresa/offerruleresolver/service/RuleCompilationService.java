package com.empresa.offerruleresolver.service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.empresa.offerruleresolver.config.CompilerProperties;
import com.empresa.offerruleresolver.exception.OfferParseException;
import com.empresa.offerruleresolver.exception.RuleRejectedException;
import com.empresa.offerruleresolver.model.dsl.CompiledRule;
import com.empresa.offerruleresolver.model.dto.CompileResponse;
import com.empresa.offerruleresolver.model.dto.RuleResult;
import com.empresa.offerruleresolver.model.dto.SandboxScenario;
import com.empresa.offerruleresolver.model.dto.TranslationContext;
import com.empresa.offerruleresolver.model.dto.ValidationError;
import com.empresa.offerruleresolver.model.dto.ValidationResult;
import com.empresa.offerruleresolver.model.offer.OfferCatalog;
import com.empresa.offerruleresolver.model.offer.OfferParser;
import com.empresa.offerruleresolver.repository.CompilationLogRepository;
import com.empresa.offerruleresolver.repository.entity.CompilationLog;

import org.springframework.ai.converter.BeanOutputConverter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * ORQUESTRADOR da camada de service — coordena as etapas do pipeline. É o único
 * ponto que a camada controller chama.
 *
 * <pre>
 *   parse oferta → (por regra) traduz+valida (retry) → sandbox → juíza → score → auditoria
 * </pre>
 *
 * Cada regra é processada de forma independente: uma regra ruim vira um resultado
 * {@code REJECTED} e não derruba o lote inteiro.
 */
@Service
public class RuleCompilationService {

	private static final String SOURCE = "AI_GENERATED";

	private final List<OfferParser> parsers;

	private final ContextBuilder contextBuilder;

	private final TranslatorService translator;

	private final RuleValidator validator;

	private final SandboxService sandbox;

	private final SemanticJudgeService judge;

	private final ConfidenceScorer scorer;

	private final CompilationLogRepository logRepository;

	private final CompilerProperties properties;

	private final String modelName;

	private final BeanOutputConverter<CompiledRule> schemaConverter = new BeanOutputConverter<>(CompiledRule.class);

	public RuleCompilationService(List<OfferParser> parsers, ContextBuilder contextBuilder,
			TranslatorService translator, RuleValidator validator, SandboxService sandbox, SemanticJudgeService judge,
			ConfidenceScorer scorer, CompilationLogRepository logRepository, CompilerProperties properties,
			@Value("${spring.ai.openai.chat.options.deployment-name:gpt-4o}") String modelName) {
		this.parsers = parsers;
		this.contextBuilder = contextBuilder;
		this.translator = translator;
		this.validator = validator;
		this.sandbox = sandbox;
		this.judge = judge;
		this.scorer = scorer;
		this.logRepository = logRepository;
		this.properties = properties;
		this.modelName = modelName;
	}

	public CompileResponse compile(Map<String, Object> offerJson, List<String> naturalLanguageRules) {
		long start = Instant.now().toEpochMilli();

		OfferCatalog catalog = resolveParser(offerJson).parse(offerJson);
		TranslationContext ctx = this.contextBuilder.build(catalog);

		List<RuleResult> results = new ArrayList<>();
		for (String nlRule : naturalLanguageRules) {
			results.add(compileOne(nlRule, ctx, catalog));
		}

		long elapsed = Instant.now().toEpochMilli() - start;
		return new CompileResponse(results,
				new CompileResponse.Metadata(this.modelName, naturalLanguageRules.size(), elapsed));
	}

	/** JSON Schema atual da DSL (para o frontend validar previews). */
	public String currentDslSchema() {
		return this.schemaConverter.getJsonSchema();
	}

	private RuleResult compileOne(String nlRule, TranslationContext ctx, OfferCatalog catalog) {
		try {
			CompiledRule rule = translateWithValidation(nlRule, ctx, catalog);

			List<SandboxScenario> truthTable = this.sandbox.truthTable(rule, catalog);
			if (this.sandbox.isUnsatisfiable(truthTable)) {
				throw new RuleRejectedException("UNSATISFIABLE",
						"Regra insatisfazível: nenhuma configuração da oferta a satisfaz.");
			}

			var verdict = this.judge.judge(nlRule, truthTable);
			RuleResult result = this.scorer.score(nlRule, rule, verdict, truthTable);

			persist(catalog.offerId(), result);
			return result;
		}
		catch (RuleRejectedException ex) {
			RuleResult rejected = RuleResult.rejected(nlRule, ex.reason(), List.of(ex.getMessage()));
			persist(catalog.offerId(), rejected);
			return rejected;
		}
	}

	/**
	 * Traduz e valida com self-correction: reinjeta os erros do validador no
	 * prompt, até {@code translator.max-retries} vezes. Esgotado, rejeita a regra.
	 */
	private CompiledRule translateWithValidation(String nlRule, TranslationContext ctx, OfferCatalog catalog) {
		List<ValidationError> feedback = List.of();
		int maxRetries = this.properties.translator().maxRetries();

		for (int attempt = 0; attempt <= maxRetries; attempt++) {
			CompiledRule rule = this.translator.translate(nlRule, ctx, feedback);
			ValidationResult validation = this.validator.validate(rule, catalog);
			if (validation.valid()) {
				return rule;
			}
			feedback = validation.errors();
		}
		throw new RuleRejectedException("VALIDATION_FAILED",
				"Não foi possível gerar uma regra válida após " + (maxRetries + 1) + " tentativa(s).");
	}

	private OfferParser resolveParser(Map<String, Object> offerJson) {
		return this.parsers.stream()
				.filter(p -> p.supports(offerJson))
				.findFirst()
				.orElseThrow(() -> new OfferParseException("Nenhum OfferParser sabe interpretar esta oferta."));
	}

	private void persist(String offerId, RuleResult result) {
		CompiledRule rule = result.rule();
		CompilationLog log = CompilationLog.builder()
				.offerId(offerId)
				.originalText(result.originalText())
				.ruleId(rule != null ? rule.id() : null)
				.ruleType(rule != null && rule.type() != null ? rule.type().name() : null)
				.compiledRule(rule != null ? rule.toString() : null)
				.confidence(result.confidence())
				.requiresHumanReview(result.requiresHumanReview())
				.status(result.status().name())
				.judgeVerdict(String.join(" | ", result.warnings()))
				.source(SOURCE)
				.createdAt(Instant.now())
				.build();
		this.logRepository.save(log);
	}
}
