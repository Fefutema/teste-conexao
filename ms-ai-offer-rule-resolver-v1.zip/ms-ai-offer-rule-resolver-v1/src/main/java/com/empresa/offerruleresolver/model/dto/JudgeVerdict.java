package com.empresa.offerruleresolver.model.dto;

import java.util.List;

/**
 * Veredito da juíza semântica. Ela compara a INTENÇÃO da frase original com o
 * COMPORTAMENTO observado (a tabela-verdade), sem ver o JSON da regra.
 *
 * @param equivalent    o comportamento corresponde à intenção da frase?
 * @param confidence    0.0–1.0 (ver critérios no prompt da juíza)
 * @param discrepancies divergências descritas em PT-BR (vazio se equivalente)
 */
public record JudgeVerdict(boolean equivalent, double confidence, List<String> discrepancies) {

	public List<String> discrepanciesOrEmpty() {
		return discrepancies == null ? List.of() : discrepancies;
	}
}
