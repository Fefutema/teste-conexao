package com.empresa.offerruleresolver.model.dto;

import java.util.Set;

/**
 * Uma linha da tabela-verdade: um estado de seleção sintético (produtos
 * selecionados) e se a regra o considera válido. Artefato central de auditoria —
 * determinístico e legível por humanos.
 *
 * @param selectedProducts productIds selecionados neste cenário
 * @param valid            a regra é satisfeita neste estado?
 */
public record SandboxScenario(Set<String> selectedProducts, boolean valid) {
}
