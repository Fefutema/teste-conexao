package com.empresa.offerruleresolver.model.dto;

import java.util.List;
import java.util.Map;

/**
 * Uma linha da tabela-verdade: um estado de seleção sintético e se a regra o
 * considera válido. É o artefato central de auditoria — determinístico e
 * legível por humanos.
 *
 * @param state estado de seleção (slotId → optionIds selecionados)
 * @param valid a regra é satisfeita neste estado?
 */
public record SandboxScenario(Map<String, List<String>> state, boolean valid) {
}
