package com.empresa.offerruleresolver.service;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.stream.Collectors;

import com.empresa.offerruleresolver.config.CompilerProperties;
import com.empresa.offerruleresolver.model.dsl.CompiledRule;
import com.empresa.offerruleresolver.model.dto.TranslationContext;
import com.empresa.offerruleresolver.model.dto.ValidationError;

import org.springframework.ai.chat.messages.Message;
import org.springframework.ai.chat.messages.SystemMessage;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.converter.BeanOutputConverter;
import org.springframework.ai.openai.OpenAiChatModel;
import org.springframework.ai.openai.OpenAiChatOptions;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

/**
 * LLM #1 — TRADUTOR. Converte uma regra em PT-BR num {@link CompiledRule} (nó
 * Rule do PDF: entrada[inMin,inMax] -&gt; saída[outMin,outMax] + Type).
 *
 * <p>Robustez: o prompt é montado em Java e enviado como mensagens (sem template
 * engine, então as chaves {@code {}} dos exemplos não quebram nada). Structured
 * output por padrão via {@link BeanOutputConverter} (instruções no prompt); com
 * {@code translator.strict-schema=true} ativa o JSON Schema nativo estrito.
 * Self-correction: os erros do validador são reinjetados no prompt.
 */
@Service
public class TranslatorService {

	private final ChatModel chatModel;

	private final CompilerProperties properties;

	private final BeanOutputConverter<CompiledRule> converter = new BeanOutputConverter<>(CompiledRule.class);

	private final String systemTemplate;

	public TranslatorService(ChatModel chatModel, CompilerProperties properties,
			@Value("classpath:prompts/translator-system.st") Resource systemPrompt) {
		this.chatModel = chatModel;
		this.properties = properties;
		this.systemTemplate = read(systemPrompt);
	}

	public CompiledRule translate(String nlRule, TranslationContext ctx, List<ValidationError> feedback) {
		String system = renderSystem(ctx) + "\n\n" + this.converter.getFormat() + correctionBlock(feedback);

		List<Message> messages = List.of(new SystemMessage(system), new UserMessage(nlRule));

		OpenAiChatOptions.Builder options = OpenAiChatOptions.builder()
				.temperature(properties.translator().temperature());
		if (properties.translator().strictSchema()) {
			options.responseFormat(OpenAiChatModel.ResponseFormat.builder()
					.jsonSchema(this.converter.getJsonSchema())
					.build());
		}

		String content = this.chatModel.call(new Prompt(messages, options.build()))
				.getResult().getOutput().getText();

		return this.converter.convert(content);
	}

	private String renderSystem(TranslationContext ctx) {
		return this.systemTemplate.replace("{{products}}", ctx.productsEnum())
				.replace("{{structure}}", ctx.offerStructure())
				.replace("{{glossary}}", ctx.glossary())
				.replace("{{fewShot}}", ctx.fewShotExamples());
	}

	private String correctionBlock(List<ValidationError> feedback) {
		if (feedback == null || feedback.isEmpty()) {
			return "";
		}
		String errors = feedback.stream()
				.map(e -> "- " + e.code() + ": " + e.message())
				.collect(Collectors.joining("\n"));
		return "\n\nATENÇÃO: sua resposta anterior foi INVÁLIDA. Corrija estes erros e responda novamente:\n" + errors;
	}

	private String read(Resource resource) {
		try {
			return resource.getContentAsString(StandardCharsets.UTF_8);
		}
		catch (IOException ex) {
			throw new UncheckedIOException("Falha ao ler prompt: " + resource.getDescription(), ex);
		}
	}
}
