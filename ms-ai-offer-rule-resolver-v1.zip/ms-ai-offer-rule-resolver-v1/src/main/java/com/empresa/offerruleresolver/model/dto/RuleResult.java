package com.empresa.offerruleresolver.model.dto;

import java.util.List;

import com.empresa.offerruleresolver.model.dsl.CompiledRule;

/**
 * Resultado da compilação de UMA regra em linguagem natural.
 *
 * @param originalText        a frase original em PT-BR
 * @param status              destino final ({@link RuleStatus})
 * @param rule                a regra compilada ({@code null} se {@code REJECTED})
 * @param confidence          confiança 0.0–1.0
 * @param requiresHumanReview precisa de aprovação humana antes de valer?
 * @param preview             tabela-verdade para o revisor conferir
 * @param warnings            avisos/ambiguidades (ex.: discrepâncias da juíza)
 * @param rejectionReason     motivo, quando {@code REJECTED} (senão {@code null})
 */
public record RuleResult(
		String originalText,
		RuleStatus status,
		CompiledRule rule,
		double confidence,
		boolean requiresHumanReview,
		List<SandboxScenario> preview,
		List<String> warnings,
		String rejectionReason) {

	public static RuleResult rejected(String originalText, String reason, List<String> warnings) {
		return new RuleResult(originalText, RuleStatus.REJECTED, null, 0.0, true, List.of(), warnings, reason);
	}
}
