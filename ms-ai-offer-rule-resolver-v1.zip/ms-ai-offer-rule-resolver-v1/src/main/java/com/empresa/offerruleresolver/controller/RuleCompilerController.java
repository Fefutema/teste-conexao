package com.empresa.offerruleresolver.controller;

import com.empresa.offerruleresolver.model.dto.CompileRequest;
import com.empresa.offerruleresolver.model.dto.CompileResponse;
import com.empresa.offerruleresolver.service.RuleCompilationService;

import jakarta.validation.Valid;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Camada web (MVC). Fina de propósito: delega toda a lógica ao
 * {@link RuleCompilationService}.
 */
@RestController
@RequestMapping("/api/v1/rules")
public class RuleCompilerController {

	private final RuleCompilationService compilationService;

	public RuleCompilerController(RuleCompilationService compilationService) {
		this.compilationService = compilationService;
	}

	/**
	 * Compila uma ou mais regras em linguagem natural contra uma oferta.
	 */
	@PostMapping("/compile")
	public CompileResponse compile(@Valid @RequestBody CompileRequest request) {
		return this.compilationService.compile(request.offerJson(), request.naturalLanguageRules());
	}

	/**
	 * JSON Schema atual da DSL (o frontend usa para validar previews).
	 */
	@GetMapping(value = "/schema", produces = MediaType.APPLICATION_JSON_VALUE)
	public String schema() {
		return this.compilationService.currentDslSchema();
	}
}
