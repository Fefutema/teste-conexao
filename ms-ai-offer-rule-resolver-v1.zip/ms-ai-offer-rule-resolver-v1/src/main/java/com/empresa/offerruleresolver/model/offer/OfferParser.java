package com.empresa.offerruleresolver.model.offer;

import java.util.Map;

/**
 * PONTO DE TROCA #1 — isola o formato (ainda instável) do {@code offerJson}.
 *
 * <p>A borda recebe a oferta como {@code Map<String,Object>} cru (não um DTO
 * rígido), então campos desconhecidos nunca quebram o parse. Quando o formato
 * mudar, escreva uma nova implementação e selecione-a por {@link #supports}.
 */
public interface OfferParser {

	OfferCatalog parse(Map<String, Object> rawOffer);

	/** Este parser sabe interpretar esta oferta? Base para roteamento por versão. */
	default boolean supports(Map<String, Object> rawOffer) {
		return true;
	}
}
