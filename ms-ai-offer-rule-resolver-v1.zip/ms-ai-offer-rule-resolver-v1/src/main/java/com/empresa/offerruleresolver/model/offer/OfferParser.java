package com.empresa.offerruleresolver.model.offer;

import java.util.Map;

/**
 * PONTO DE TROCA #1 — isola o formato do JSON da oferta. A oferta SEMPRE chega
 * como um JSON completo (mapeado para {@code Map<String,Object>} cru na borda);
 * este parser o converte no modelo canônico em árvore {@link OfferModel}.
 *
 * <p>Quando o formato do JSON mudar, escreve-se uma nova implementação e
 * seleciona-se por {@link #supports}. A borda HTTP não muda.
 */
public interface OfferParser {

	OfferModel parse(Map<String, Object> rawOffer);

	default boolean supports(Map<String, Object> rawOffer) {
		return true;
	}
}
