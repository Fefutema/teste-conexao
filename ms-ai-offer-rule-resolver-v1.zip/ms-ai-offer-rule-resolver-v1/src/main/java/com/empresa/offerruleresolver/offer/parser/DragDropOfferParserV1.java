package com.empresa.offerruleresolver.offer.parser;

import java.util.List;
import java.util.Map;

import com.empresa.offerruleresolver.exception.OfferParseException;
import com.empresa.offerruleresolver.model.offer.CatalogSlot;
import com.empresa.offerruleresolver.model.offer.OfferCatalog;
import com.empresa.offerruleresolver.model.offer.OfferParser;

import org.springframework.stereotype.Component;

/**
 * Implementação atual do {@link OfferParser} para o formato gerado pelo backoffice
 * drag-and-drop:
 *
 * <pre>
 * { "offerId": "...", "name": "...", "slots": [
 *     { "id": "phone", "minQty": 1, "maxQty": 1,
 *       "options": [ { "id": "iphone-15", "label": "iPhone 15" } ] } ] }
 * </pre>
 *
 * Navega o {@code Map} cru de forma tolerante: campos extras/desconhecidos são
 * ignorados. Quando o formato mudar, escreva {@code DragDropOfferParserV2} e
 * selecione por {@link OfferParser#supports}.
 */
@Component
public class DragDropOfferParserV1 implements OfferParser {

	@Override
	@SuppressWarnings("unchecked")
	public OfferCatalog parse(Map<String, Object> rawOffer) {
		if (rawOffer == null) {
			throw new OfferParseException("offerJson ausente");
		}
		try {
			String offerId = asString(rawOffer.get("offerId"), "offerId");
			Object slotsRaw = rawOffer.get("slots");
			if (!(slotsRaw instanceof List<?> slotsList) || slotsList.isEmpty()) {
				throw new OfferParseException("offerJson.slots ausente ou vazio");
			}

			List<CatalogSlot> slots = slotsList.stream()
					.map(o -> (Map<String, Object>) o)
					.map(this::toSlot)
					.toList();

			return new OfferCatalog(offerId, slots);
		}
		catch (OfferParseException ex) {
			throw ex;
		}
		catch (RuntimeException ex) {
			throw new OfferParseException("offerJson em formato inesperado: " + ex.getMessage(), ex);
		}
	}

	@SuppressWarnings("unchecked")
	private CatalogSlot toSlot(Map<String, Object> slot) {
		String id = asString(slot.get("id"), "slot.id");
		int minQty = asInt(slot.get("minQty"), 0);
		int maxQty = asInt(slot.get("maxQty"), 1);

		Object optionsRaw = slot.getOrDefault("options", List.of());
		if (!(optionsRaw instanceof List<?> optionsList)) {
			throw new OfferParseException("slot '" + id + "' com options em formato inesperado");
		}
		List<String> optionIds = optionsList.stream()
				.map(o -> (Map<String, Object>) o)
				.map(opt -> asString(opt.get("id"), "option.id"))
				.toList();

		return new CatalogSlot(id, minQty, maxQty, optionIds);
	}

	private String asString(Object value, String field) {
		if (value == null) {
			throw new OfferParseException("campo obrigatório ausente: " + field);
		}
		return value.toString();
	}

	private int asInt(Object value, int defaultValue) {
		if (value == null) {
			return defaultValue;
		}
		if (value instanceof Number n) {
			return n.intValue();
		}
		return Integer.parseInt(value.toString());
	}
}
