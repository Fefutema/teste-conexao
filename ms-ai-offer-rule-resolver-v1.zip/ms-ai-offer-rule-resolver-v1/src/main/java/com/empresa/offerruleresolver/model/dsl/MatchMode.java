package com.empresa.offerruleresolver.model.dsl;

/**
 * Como uma {@link SlotRef} é comparada contra o estado de seleção do usuário.
 */
public enum MatchMode {

	/** O slot tem pelo menos uma opção selecionada. */
	ANY_SELECTED,

	/** O slot não tem nenhuma opção selecionada. */
	NONE_SELECTED,

	/** Pelo menos uma das opções em {@code optionIds} está selecionada. */
	SPECIFIC_OPTIONS
}
