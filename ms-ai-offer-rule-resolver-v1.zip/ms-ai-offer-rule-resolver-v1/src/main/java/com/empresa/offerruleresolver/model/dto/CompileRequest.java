package com.empresa.offerruleresolver.model.dto;

import java.util.List;
import java.util.Map;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

/**
 * Corpo da requisição de {@code POST /api/v1/rules/compile}.
 *
 * <p>{@code offerJson} chega CRU como {@code Map<String,Object>} — de propósito:
 * o serviço não se acopla ao formato externo da oferta (ponto volátil #1). O
 * {@code OfferParser} converte para o modelo canônico interno.
 *
 * @param offerJson             a oferta, no formato do backoffice (cru)
 * @param naturalLanguageRules  regras em PT-BR, uma por item
 * @param locale                locale das mensagens (ex.: {@code "pt-BR"})
 */
public record CompileRequest(
		@NotNull Map<String, Object> offerJson,
		@NotEmpty List<String> naturalLanguageRules,
		String locale) {

	public String localeOrDefault() {
		return (locale == null || locale.isBlank()) ? "pt-BR" : locale;
	}
}
