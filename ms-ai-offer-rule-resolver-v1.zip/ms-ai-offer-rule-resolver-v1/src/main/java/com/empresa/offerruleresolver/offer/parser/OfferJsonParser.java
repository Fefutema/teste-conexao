package com.empresa.offerruleresolver.offer.parser;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.empresa.offerruleresolver.exception.OfferParseException;
import com.empresa.offerruleresolver.model.offer.NodeType;
import com.empresa.offerruleresolver.model.offer.OfferModel;
import com.empresa.offerruleresolver.model.offer.OfferNode;
import com.empresa.offerruleresolver.model.offer.OfferParser;
import com.empresa.offerruleresolver.model.offer.RelatedEdge;

import org.springframework.stereotype.Component;

/**
 * Parser do JSON da oferta em ÁRVORE (modelo do PDF). Walk recursivo de 'contains'
 * (campo {@code children}) + arestas 'related'.
 *
 * <p>Shape esperado (campos extras ignorados):
 * <pre>
 * { "root": { "id":"bolota","type":"ROOT","selectMin":2,"selectMax":2,"children":[
 *     { "id":"plano","type":"GROUP","selectMin":1,"selectMax":1,"children":[
 *         { "id":"30GB","type":"PRODUCT","qtyMin":1,"qtyMax":2 } ] } ] },
 *   "related":[ { "from":"carregador-usb-c","to":"iphone-branco" } ] }
 * </pre>
 *
 * <p>Validações (falha explícita, sem "adivinhar"): cardinalidade de agrupamento
 * {@code 0 <= selectMin <= selectMax <= nº de filhos}; {@code type} conhecido;
 * um {@code children} presente (mesmo vazio) marca GROUP; janelas de qty sãs.
 */
@Component
public class OfferJsonParser implements OfferParser {

	@Override
	@SuppressWarnings("unchecked")
	public OfferModel parse(Map<String, Object> rawOffer) {
		if (rawOffer == null || rawOffer.isEmpty()) {
			throw new OfferParseException("offerJson ausente ou vazio");
		}
		try {
			Object rootRaw = rawOffer.getOrDefault("root", rawOffer);
			Map<String, Object> rootMap = asMap(rootRaw, "root");
			OfferNode root = toNode(rootMap, NodeType.ROOT);

			return new OfferModel(root, parseRelated(rawOffer.get("related")));
		}
		catch (OfferParseException ex) {
			throw ex;
		}
		catch (RuntimeException ex) {
			throw new OfferParseException("offerJson em formato inesperado: " + ex.getMessage(), ex);
		}
	}

	private OfferNode toNode(Map<String, Object> node, NodeType fallbackType) {
		String id = asString(node.get("id"), "node.id");

		Object childrenRaw = node.get("children");
		boolean childrenDeclared = childrenRaw instanceof List<?>;
		List<OfferNode> children = new ArrayList<>();
		if (childrenRaw instanceof List<?> list) {
			for (Object child : list) {
				children.add(toNode(asMap(child, "children[] de '" + id + "'"), NodeType.GROUP));
			}
		}

		NodeType type = resolveType(node.get("type"), fallbackType, childrenDeclared, id);

		int childCount = children.size();
		int selectMin = asInt(node.get("selectMin"), 0, id);
		int selectMax = asInt(node.get("selectMax"), childCount, id);
		int qtyMin = asInt(node.get("qtyMin"), 1, id);
		int qtyMax = asInt(node.get("qtyMax"), 1, id);

		if (type != NodeType.PRODUCT && (selectMin < 0 || selectMax < selectMin || selectMax > childCount)) {
			throw new OfferParseException("cardinalidade de seleção inválida no agrupamento '" + id
					+ "': exige 0 <= selectMin <= selectMax <= nº de filhos (" + childCount + "), recebido " + selectMin
					+ ".." + selectMax);
		}
		if (qtyMin < 0 || qtyMax < qtyMin) {
			throw new OfferParseException("quantidade inválida no produto '" + id + "': " + qtyMin + ".." + qtyMax);
		}

		return new OfferNode(id, type, selectMin, selectMax, qtyMin, qtyMax, children);
	}

	private NodeType resolveType(Object rawType, NodeType fallback, boolean childrenDeclared, String id) {
		if (rawType != null) {
			try {
				return NodeType.valueOf(rawType.toString().trim().toUpperCase());
			}
			catch (IllegalArgumentException ex) {
				throw new OfferParseException(
						"type inválido '" + rawType + "' no nó '" + id + "'. Válidos: ROOT, GROUP, PRODUCT");
			}
		}
		// 'children' declarado (mesmo vazio) indica agrupamento; senão, folha.
		return childrenDeclared ? fallback : NodeType.PRODUCT;
	}

	private List<RelatedEdge> parseRelated(Object relatedRaw) {
		if (!(relatedRaw instanceof List<?> list)) {
			return List.of();
		}
		List<RelatedEdge> edges = new ArrayList<>();
		for (Object item : list) {
			Map<String, Object> edge = asMap(item, "related[]");
			edges.add(new RelatedEdge(asString(edge.get("from"), "related.from"),
					asString(edge.get("to"), "related.to")));
		}
		return edges;
	}

	@SuppressWarnings("unchecked")
	private Map<String, Object> asMap(Object value, String field) {
		if (value instanceof Map<?, ?> map) {
			return (Map<String, Object>) map;
		}
		throw new OfferParseException(field + " deveria ser um objeto JSON");
	}

	private String asString(Object value, String field) {
		if (value == null) {
			throw new OfferParseException("campo obrigatório ausente: " + field);
		}
		return value.toString();
	}

	private int asInt(Object value, int defaultValue, String context) {
		if (value == null) {
			return defaultValue;
		}
		if (value instanceof Number n) {
			return n.intValue();
		}
		try {
			return Integer.parseInt(value.toString().trim());
		}
		catch (NumberFormatException ex) {
			throw new OfferParseException("valor numérico inválido em '" + context + "': " + value);
		}
	}
}
