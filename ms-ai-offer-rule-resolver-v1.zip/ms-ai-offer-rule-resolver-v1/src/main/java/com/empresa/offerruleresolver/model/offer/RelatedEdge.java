package com.empresa.offerruleresolver.model.offer;

/**
 * Aresta 'related' do PDF: cross-sell / compre-junto. EXPLICITAMENTE FORA do
 * bundle — não entra na montagem nem na enumeração do sandbox. É apenas uma
 * indicação de "compre junto".
 */
public record RelatedEdge(String fromProductId, String toProductId) {
}
