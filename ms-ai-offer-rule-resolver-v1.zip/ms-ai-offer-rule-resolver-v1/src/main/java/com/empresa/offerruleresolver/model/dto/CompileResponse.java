package com.empresa.offerruleresolver.model.dto;

import java.util.List;

/**
 * Resposta de {@code POST /api/v1/rules/compile}. Um {@link RuleResult} por regra
 * NL enviada (o lote nunca falha inteiro por causa de uma regra ruim).
 */
public record CompileResponse(List<RuleResult> results, Metadata metadata) {

	public record Metadata(String model, int totalRules, long elapsedMs) {
	}
}
