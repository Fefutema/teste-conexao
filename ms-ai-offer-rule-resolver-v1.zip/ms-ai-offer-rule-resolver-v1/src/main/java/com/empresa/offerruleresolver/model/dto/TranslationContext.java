package com.empresa.offerruleresolver.model.dto;

/**
 * Todo o contexto que o {@code ContextBuilder} prepara para o prompt da LLM
 * tradutora. Injetar os IDs válidos no prompt é a principal defesa contra
 * alucinação de slotId/optionId.
 *
 * @param slotsEnum        lista achatada de slotIds válidos, legível
 * @param optionsEnum      opções válidas por slot, legível
 * @param fewShotExamples  exemplos pareados (texto bruto do golden-set)
 * @param glossary         sinônimos (texto bruto do glossário)
 */
public record TranslationContext(
		String slotsEnum,
		String optionsEnum,
		String fewShotExamples,
		String glossary) {
}
