package com.empresa.offerruleresolver.model.dto;

/**
 * Contexto que o {@code ContextBuilder} prepara para o prompt da LLM tradutora.
 * Injetar os productIds VÁLIDOS e a estrutura da oferta reduz alucinação.
 *
 * @param productsEnum     lista achatada de productIds válidos
 * @param offerStructure   a árvore da oferta renderizada (grupos + cardinalidades)
 * @param fewShotExamples  exemplos pareados (texto do golden-set)
 * @param glossary         sinônimos (texto do glossário)
 */
public record TranslationContext(
		String productsEnum,
		String offerStructure,
		String fewShotExamples,
		String glossary) {
}
