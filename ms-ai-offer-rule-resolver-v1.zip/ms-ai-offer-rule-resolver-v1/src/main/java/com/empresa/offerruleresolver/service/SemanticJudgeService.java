package com.empresa.offerruleresolver.service;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.stream.Collectors;

import com.empresa.offerruleresolver.config.CompilerProperties;
import com.empresa.offerruleresolver.model.dto.JudgeVerdict;
import com.empresa.offerruleresolver.model.dto.SandboxScenario;

import org.springframework.ai.chat.messages.Message;
import org.springframework.ai.chat.messages.SystemMessage;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.converter.BeanOutputConverter;
import org.springframework.ai.openai.OpenAiChatModel;
import org.springframework.ai.openai.OpenAiChatOptions;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

/**
 * LLM #2 — JUÍZA SEMÂNTICA. Compara a INTENÇÃO da frase original com o
 * COMPORTAMENTO observado (a tabela-verdade). <b>Não vê o JSON da regra</b> — é
 * isso que a torna útil mesmo usando o mesmo modelo do tradutor: a tarefa é
 * diferente e o sandbox determinístico fica no meio.
 *
 * <p>Limitação assumida: modelo único mantém pontos-cegos correlacionados; por
 * isso a Fase 1 força revisão humana e a Fase 2 adiciona self-consistency.
 */
@Service
public class SemanticJudgeService {

	private final ChatModel chatModel;

	private final CompilerProperties properties;

	private final BeanOutputConverter<JudgeVerdict> converter = new BeanOutputConverter<>(JudgeVerdict.class);

	private final String systemPrompt;

	private final String userTemplate;

	public SemanticJudgeService(ChatModel chatModel, CompilerProperties properties,
			@Value("classpath:prompts/judge-system.st") Resource systemPrompt,
			@Value("classpath:prompts/judge-user.st") Resource userTemplate) {
		this.chatModel = chatModel;
		this.properties = properties;
		this.systemPrompt = read(systemPrompt);
		this.userTemplate = read(userTemplate);
	}

	public JudgeVerdict judge(String originalNl, List<SandboxScenario> scenarios) {
		String system = this.systemPrompt + "\n\n" + this.converter.getFormat();
		String user = this.userTemplate.replace("{{nl}}", originalNl)
				.replace("{{scenariosTable}}", renderTable(scenarios));

		List<Message> messages = List.of(new SystemMessage(system), new UserMessage(user));

		OpenAiChatOptions.Builder options = OpenAiChatOptions.builder()
				.temperature(properties.judge().temperature());
		if (properties.judge().strictSchema()) {
			options.responseFormat(OpenAiChatModel.ResponseFormat.builder()
					.jsonSchema(this.converter.getJsonSchema())
					.build());
		}

		String content = this.chatModel.call(new Prompt(messages, options.build()))
				.getResult().getOutput().getText();

		return this.converter.convert(content);
	}

	/** A juíza vê a TABELA-VERDADE, não o JSON. */
	private String renderTable(List<SandboxScenario> scenarios) {
		return scenarios.stream()
				.map(s -> "- Seleção " + s.state() + " => " + (s.valid() ? "VÁLIDO" : "INVÁLIDO"))
				.collect(Collectors.joining("\n"));
	}

	private String read(Resource resource) {
		try {
			return resource.getContentAsString(StandardCharsets.UTF_8);
		}
		catch (IOException ex) {
			throw new UncheckedIOException("Falha ao ler prompt: " + resource.getDescription(), ex);
		}
	}
}
