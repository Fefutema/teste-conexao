package com.empresa.offerruleresolver.service;

import java.util.ArrayList;
import java.util.List;

import com.empresa.offerruleresolver.model.dsl.CompiledRule;
import com.empresa.offerruleresolver.model.dsl.MatchMode;
import com.empresa.offerruleresolver.model.dsl.RuleType;
import com.empresa.offerruleresolver.model.dsl.SlotRef;
import com.empresa.offerruleresolver.model.dto.ValidationError;
import com.empresa.offerruleresolver.model.dto.ValidationResult;
import com.empresa.offerruleresolver.model.offer.CatalogSlot;
import com.empresa.offerruleresolver.model.offer.OfferCatalog;

import org.springframework.stereotype.Service;

/**
 * Etapa mais importante do pipeline: o guardrail determinístico (SEM LLM). Toda
 * saída da LLM passa por aqui antes de qualquer decisão. Verifica validade
 * ESTRUTURAL e de referências; a satisfazibilidade ({@code UNSATISFIABLE}) é
 * derivada da tabela-verdade do sandbox pelo orquestrador.
 *
 * <p>As mensagens de erro são desenhadas para serem reinjetadas no prompt
 * (self-correction): incluem os valores válidos.
 */
@Service
public class RuleValidator {

	public ValidationResult validate(CompiledRule rule, OfferCatalog catalog) {
		List<ValidationError> errors = new ArrayList<>();

		if (isBlank(rule.id())) {
			errors.add(new ValidationError("MISSING_ID", "A regra precisa de um 'id' kebab-case não vazio."));
		}
		if (rule.type() == null) {
			errors.add(new ValidationError("INVALID_TYPE",
					"Campo 'type' ausente. Valores válidos: " + List.of(RuleType.values())));
		}
		if (isBlank(rule.userFacingMessage())) {
			errors.add(new ValidationError("MISSING_MESSAGE", "Campo 'userFacingMessage' não pode ser vazio."));
		}

		for (SlotRef ref : rule.antecedentsOrEmpty()) {
			validateRef(ref, catalog, errors);
		}
		for (SlotRef ref : rule.consequentsOrEmpty()) {
			validateRef(ref, catalog, errors);
		}

		if (rule.type() == RuleType.MIN_SELECTION && rule.paramsOrEmpty().min() == null) {
			errors.add(new ValidationError("MISSING_PARAM", "MIN_SELECTION exige 'params.min' (inteiro)."));
		}

		return ValidationResult.of(errors);
	}

	private void validateRef(SlotRef ref, OfferCatalog catalog, List<ValidationError> errors) {
		if (ref == null || isBlank(ref.slotId())) {
			errors.add(new ValidationError("UNKNOWN_SLOT", "Referência de slot sem 'slotId'."));
			return;
		}
		CatalogSlot slot = catalog.slot(ref.slotId()).orElse(null);
		if (slot == null) {
			errors.add(new ValidationError("UNKNOWN_SLOT",
					"slotId '" + ref.slotId() + "' não existe. Slots válidos: " + catalog.slotIds()));
			return;
		}
		if (ref.match() == MatchMode.SPECIFIC_OPTIONS) {
			for (String optionId : ref.optionIdsOrEmpty()) {
				if (!slot.hasOption(optionId)) {
					errors.add(new ValidationError("OPTION_NOT_IN_SLOT",
							"optionId '" + optionId + "' não pertence ao slot '" + slot.id() + "'. Opções válidas: "
									+ slot.optionIds()));
				}
			}
		}
	}

	private boolean isBlank(String value) {
		return value == null || value.isBlank();
	}
}
