package com.empresa.offerruleresolver.service;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import com.empresa.offerruleresolver.model.dsl.CompiledRule;
import com.empresa.offerruleresolver.model.dsl.RuleType;
import com.empresa.offerruleresolver.model.dto.ValidationError;
import com.empresa.offerruleresolver.model.dto.ValidationResult;
import com.empresa.offerruleresolver.model.offer.OfferModel;

import org.springframework.stereotype.Service;

/**
 * Guardrail determinístico (SEM LLM). Verifica validade estrutural da regra
 * contra a oferta. A satisfazibilidade ({@code UNSATISFIABLE}) é derivada da
 * tabela-verdade do sandbox pelo orquestrador. As mensagens são desenhadas para
 * reinjeção no prompt (self-correction).
 */
@Service
public class RuleValidator {

	public ValidationResult validate(CompiledRule rule, OfferModel offer) {
		List<ValidationError> errors = new ArrayList<>();

		if (isBlank(rule.id())) {
			errors.add(new ValidationError("MISSING_ID", "A regra precisa de um 'id' kebab-case não vazio."));
		}
		if (rule.type() == null) {
			errors.add(new ValidationError("INVALID_TYPE",
					"Campo 'type' ausente. Valores válidos: " + List.of(RuleType.values())));
		}
		if (isBlank(rule.userFacingMessage())) {
			errors.add(new ValidationError("MISSING_MESSAGE", "Campo 'userFacingMessage' não pode ser vazio."));
		}

		Set<String> validProducts = offer.allProductIds();
		checkProducts(rule.inputOrEmpty(), "input", validProducts, errors);
		checkProducts(rule.outputOrEmpty(), "output", validProducts, errors);

		if (rule.inputOrEmpty().isEmpty()) {
			errors.add(new ValidationError("EMPTY_INPUT", "A regra precisa de ao menos 1 produto na entrada (gatilho)."));
		}
		if (rule.outputOrEmpty().isEmpty()) {
			errors.add(new ValidationError("EMPTY_OUTPUT", "A regra precisa de ao menos 1 produto na saída (efeito)."));
		}

		checkWindow(rule.inMin(), rule.inMax(), rule.inputOrEmpty().size(), "INPUT", true, errors);
		checkWindow(rule.outMin(), rule.outMax(), rule.outputOrEmpty().size(), "OUTPUT", false, errors);

		Set<String> overlap = new LinkedHashSet<>(rule.inputOrEmpty());
		overlap.retainAll(rule.outputOrEmpty());
		if (!overlap.isEmpty()) {
			errors.add(new ValidationError("INPUT_OUTPUT_OVERLAP",
					"Produtos aparecem na entrada E na saída: " + overlap + " (gatilho e efeito não devem se sobrepor)."));
		}

		return ValidationResult.of(errors);
	}

	private void checkProducts(List<String> ids, String side, Set<String> valid, List<ValidationError> errors) {
		for (String id : ids) {
			if (!valid.contains(id)) {
				errors.add(new ValidationError("UNKNOWN_PRODUCT",
						"productId '" + id + "' (" + side + ") não existe na oferta."));
			}
		}
	}

	/**
	 * Valida uma janela de cardinalidade contra a aridade do conjunto. {@code requireMinOne}
	 * exige min &gt;= 1 (usado na ENTRADA: sem gatilho selecionado não há regra).
	 */
	private void checkWindow(int min, int max, int arity, String side, boolean requireMinOne,
			List<ValidationError> errors) {
		String code = "INVALID_" + side + "_WINDOW";
		if (min < 0 || max < min) {
			errors.add(new ValidationError(code,
					"Janela de " + side.toLowerCase() + " inválida: exige 0 <= min <= max (recebido " + min + ".." + max
							+ ")."));
			return;
		}
		if (requireMinOne && min < 1) {
			errors.add(new ValidationError(code,
					"Janela de entrada exige min >= 1 (a regra precisa de ao menos 1 produto de gatilho para disparar)."));
		}
		if (min > arity) {
			errors.add(new ValidationError(code, "Janela de " + side.toLowerCase() + " impossível: min (" + min
					+ ") é maior que o nº de produtos de " + side.toLowerCase() + " (" + arity + ")."));
		}
	}

	private boolean isBlank(String value) {
		return value == null || value.isBlank();
	}
}
