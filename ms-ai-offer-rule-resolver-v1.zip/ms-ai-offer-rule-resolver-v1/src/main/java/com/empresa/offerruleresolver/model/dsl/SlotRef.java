package com.empresa.offerruleresolver.model.dsl;

import java.util.List;

/**
 * Referência a um slot (e opcionalmente a opções específicas dele) usada em
 * antecedentes/consequentes de uma regra.
 *
 * @param slotId    id do slot referenciado (deve existir no {@code OfferCatalog})
 * @param match     como comparar contra a seleção do usuário
 * @param optionIds opções específicas; relevante apenas quando
 *                  {@code match == SPECIFIC_OPTIONS} (caso contrário pode vir
 *                  vazia/nula)
 */
public record SlotRef(String slotId, MatchMode match, List<String> optionIds) {

	public List<String> optionIdsOrEmpty() {
		return optionIds == null ? List.of() : optionIds;
	}
}
