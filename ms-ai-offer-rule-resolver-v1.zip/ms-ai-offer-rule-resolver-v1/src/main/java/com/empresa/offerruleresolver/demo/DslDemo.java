package com.empresa.offerruleresolver.demo;

import java.util.ArrayList;
import java.util.List;

import com.empresa.offerruleresolver.config.CompilerProperties;
import com.empresa.offerruleresolver.model.dsl.CompiledRule;
import com.empresa.offerruleresolver.model.dsl.RuleEvaluator;
import com.empresa.offerruleresolver.model.dsl.RuleType;
import com.empresa.offerruleresolver.model.dto.SandboxScenario;
import com.empresa.offerruleresolver.model.dto.TruthTable;
import com.empresa.offerruleresolver.model.dto.ValidationResult;
import com.empresa.offerruleresolver.model.offer.NodeType;
import com.empresa.offerruleresolver.model.offer.OfferModel;
import com.empresa.offerruleresolver.model.offer.OfferNode;
import com.empresa.offerruleresolver.service.RuleValidator;
import com.empresa.offerruleresolver.service.SandboxService;

/**
 * Demonstração AUTOCONTIDA do "offer rule dsl" — roda com {@code java}, sem
 * Spring, sem Azure, sem banco, sem LLM. É a parte DETERMINÍSTICA da apresentação:
 * mostra, para o time técnico do executor, exatamente como cada regra se comporta
 * (a tabela-verdade), e para o negócio, que a frase vira uma regra auditável.
 *
 * <p>Rodar (após compilar o projeto):
 * <pre>
 *   mvn -q compile
 *   java -cp target/classes com.empresa.offerruleresolver.demo.DslDemo
 * </pre>
 * ou simplesmente "Run" no {@code main} pela IDE.
 */
public final class DslDemo {

	private static final RuleEvaluator EVALUATOR = new RuleEvaluator();

	private static final SandboxService SANDBOX = new SandboxService(EVALUATOR,
			new CompilerProperties(new CompilerProperties.Translator(0.1, 2, false),
					new CompilerProperties.Judge(0.0, false), new CompilerProperties.Confidence(0.9, 0.6, true),
					new CompilerProperties.Sandbox(64)));

	private static final RuleValidator VALIDATOR = new RuleValidator();

	private DslDemo() {
	}

	public static void main(String[] args) {
		OfferModel offer = comboOffer();
		printHeader(offer);

		demo("Se levar FONE ou CAPA, o celular A é obrigatório.  (porta OR)",
				rule("or", RuleType.REQUIRES, List.of("fone", "capa"), 1, 2, List.of("celular-a"), 1, 1), offer);

		demo("Se levar FONE e CAPA juntos, o celular B é obrigatório.  (porta AND)",
				rule("and", RuleType.REQUIRES, List.of("fone", "capa"), 2, 2, List.of("celular-b"), 1, 1), offer);

		demo("Se levar EXATAMENTE UM entre fone e capa, o celular A é obrigatório.  (porta XOR)",
				rule("xor", RuleType.REQUIRES, List.of("fone", "capa"), 1, 1, List.of("celular-a"), 1, 1), offer);

		demo("Se levar a CAPA, NÃO pode levar o celular B.  (INCOMPATIBLE_WITH)",
				rule("inc", RuleType.INCOMPATIBLE_WITH, List.of("capa"), 1, 1, List.of("celular-b"), 1, 1), offer);

		System.out.println("Fim da demonstração. A mesma semântica (RuleEvaluator) é o que o executor deve reproduzir.");
	}

	/** Oferta "Combo" pequena e legível: aparelho (1 de 1) + extras (0 a 2). */
	private static OfferModel comboOffer() {
		OfferNode aparelho = group("aparelho", 1, 1, product("celular-a"), product("celular-b"));
		OfferNode extras = group("extras", 0, 2, product("fone"), product("capa"));
		OfferNode root = new OfferNode("combo", NodeType.ROOT, 2, 2, 0, 0, List.of(aparelho, extras));
		return new OfferModel(root, List.of());
	}

	private static void demo(String frase, CompiledRule rule, OfferModel offer) {
		System.out.println("──────────────────────────────────────────────────────────────");
		System.out.println("FRASE (negócio): " + frase);
		System.out.println("REGRA (técnico): " + describe(rule));

		ValidationResult validation = VALIDATOR.validate(rule, offer);
		System.out.println("Validação determinística: " + (validation.valid() ? "OK" : "FALHOU " + validation.errors()));

		TruthTable table = SANDBOX.truthTable(rule, offer);
		System.out.println("Tabela-verdade (" + table.scenarios().size() + " cenários"
				+ (table.truncated() ? ", TRUNCADA" : "") + "):");
		table.scenarios().stream()
				.map(DslDemo::formatScenario)
				.sorted()
				.forEach(line -> System.out.println("   " + line));
		System.out.println();
	}

	private static String formatScenario(SandboxScenario s) {
		List<String> sorted = new ArrayList<>(s.selectedProducts());
		sorted.sort(String::compareTo);
		String sel = String.format("%-28s", sorted);
		return sel + " => " + (s.valid() ? "VÁLIDO" : "INVÁLIDO");
	}

	private static String describe(CompiledRule r) {
		return r.type() + "  entrada=" + r.input() + " " + r.inMin() + ".." + r.inMax()
				+ "  ->  saída=" + r.output() + " " + r.outMin() + ".." + r.outMax();
	}

	private static void printHeader(OfferModel offer) {
		System.out.println("══════════════════════════════════════════════════════════════");
		System.out.println(" DEMONSTRAÇÃO DO OFFER RULE DSL");
		System.out.println(" Oferta: Combo");
		System.out.println("   aparelho (escolha 1 de 1): celular-a, celular-b");
		System.out.println("   extras   (escolha 0 a 2):  fone, capa");
		System.out.println(" Produtos válidos: " + offer.allProductIds());
		System.out.println("══════════════════════════════════════════════════════════════");
		System.out.println();
	}

	private static CompiledRule rule(String id, RuleType type, List<String> in, int inMin, int inMax, List<String> out,
			int outMin, int outMax) {
		return new CompiledRule(id, type, in, inMin, inMax, out, outMin, outMax, "demo");
	}

	private static OfferNode product(String id) {
		return new OfferNode(id, NodeType.PRODUCT, 0, 0, 1, 1, List.of());
	}

	private static OfferNode group(String id, int selMin, int selMax, OfferNode... children) {
		return new OfferNode(id, NodeType.GROUP, selMin, selMax, 0, 0, List.of(children));
	}
}
