package com.empresa.offerruleresolver.model.dsl;

import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Component;

/**
 * ÚNICA fonte da <b>semântica</b> da regra. Código determinístico puro (sem LLM).
 * O sandbox usa este avaliador para gerar a tabela-verdade.
 *
 * <p>Modelo do PDF: a regra DISPARA quando a contagem de ENTRADA selecionada cai
 * na janela [inMin, inMax]; quando disparada, VALIDA a contagem de SAÍDA contra a
 * janela [outMin, outMax]. A janela de saída é usada nos DOIS tipos — em REQUIRES
 * a saída deve cair nela; em INCOMPATIBLE_WITH a saída NÃO pode cair nela (a
 * janela é a zona proibida). Assim nenhum campo vira código morto.
 *
 * <p><b>Contrato crítico:</b> esta semântica precisa ser idêntica à do engine de
 * runtime que executa as ofertas. Se divergir, a tabela-verdade aprovada no
 * preview mente. O ideal é extrair este pacote para uma biblioteca compartilhada.
 */
@Component
public class RuleEvaluator {

	/** A regra é satisfeita pela seleção de produtos informada? */
	public boolean isSatisfied(ConfigState state, CompiledRule rule) {
		Set<String> selected = state.selectedOrEmpty();

		int in = countSelected(rule.inputOrEmpty(), selected);
		boolean triggered = in >= rule.inMin() && in <= rule.inMax();
		if (!triggered) {
			return true; // regra não disparou => vacuamente satisfeita
		}

		int out = countSelected(rule.outputOrEmpty(), selected);
		boolean outInWindow = out >= rule.outMin() && out <= rule.outMax();

		return switch (rule.type()) {
			case REQUIRES -> outInWindow;           // a saída DEVE cair na janela
			case INCOMPATIBLE_WITH -> !outInWindow; // a saída NÃO pode cair na janela (proibida)
		};
	}

	private int countSelected(List<String> productIds, Set<String> selected) {
		// distinct(): a contagem é de PRODUTOS distintos; ids repetidos na lista não inflam a janela.
		return (int) productIds.stream().distinct().filter(selected::contains).count();
	}
}
