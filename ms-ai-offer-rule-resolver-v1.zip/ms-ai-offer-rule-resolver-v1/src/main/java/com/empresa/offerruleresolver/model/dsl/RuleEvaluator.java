package com.empresa.offerruleresolver.model.dsl;

import java.util.List;

import org.springframework.stereotype.Component;

/**
 * ÚNICA fonte da <b>semântica</b> dos operadores da DSL. É código determinístico
 * puro (sem LLM). O sandbox usa este avaliador para gerar a tabela-verdade.
 *
 * <p><b>Contrato crítico:</b> esta semântica precisa ser idêntica à do engine de
 * runtime ({@code ms-offers-v1}). Se divergir, a tabela-verdade aprovada no
 * preview mente. O ideal é extrair este pacote para uma biblioteca compartilhada
 * entre os dois serviços (ver plano, seção "Risco crítico").
 *
 * <p>Para evoluir a DSL, adicione/altere um {@code case} aqui — é o único lugar
 * onde a semântica vive.
 */
@Component
public class RuleEvaluator {

	/**
	 * A regra é satisfeita pelo estado de seleção informado?
	 */
	public boolean isSatisfied(ConfigState state, CompiledRule rule) {
		List<SlotRef> antecedents = rule.antecedentsOrEmpty();
		List<SlotRef> consequents = rule.consequentsOrEmpty();
		return switch (rule.type()) {
			case REQUIRES -> !allMatch(state, antecedents) || allMatch(state, consequents);
			case EXCLUDES -> !allMatch(state, antecedents) || noneSelectedIn(state, consequents);
			case ONE_OF -> countSelectedInScope(state, antecedents) == 1;
			case MIN_SELECTION -> countSelectedInScope(state, antecedents) >= minOf(rule);
		};
	}

	private boolean allMatch(ConfigState state, List<SlotRef> refs) {
		// Lista vazia = condição vacuamente verdadeira (regra incondicional).
		return refs.stream().allMatch(ref -> refMatches(state, ref));
	}

	private boolean refMatches(ConfigState state, SlotRef ref) {
		return switch (ref.match()) {
			case ANY_SELECTED -> !state.isSlotEmpty(ref.slotId());
			case NONE_SELECTED -> state.isSlotEmpty(ref.slotId());
			case SPECIFIC_OPTIONS -> ref.optionIdsOrEmpty().stream()
					.anyMatch(opt -> state.selected(ref.slotId()).contains(opt));
		};
	}

	/** Para {@code EXCLUDES}: nenhum dos consequentes pode ter opção selecionada em seu escopo. */
	private boolean noneSelectedIn(ConfigState state, List<SlotRef> refs) {
		return refs.stream().allMatch(ref -> scopeCount(state, ref) == 0);
	}

	private int countSelectedInScope(ConfigState state, List<SlotRef> refs) {
		return refs.stream().mapToInt(ref -> scopeCount(state, ref)).sum();
	}

	/** Quantas opções selecionadas do slot caem no "escopo" da referência. */
	private int scopeCount(ConfigState state, SlotRef ref) {
		List<String> selected = state.selected(ref.slotId());
		return switch (ref.match()) {
			case ANY_SELECTED -> selected.size();
			case NONE_SELECTED -> 0;
			case SPECIFIC_OPTIONS -> (int) selected.stream()
					.filter(opt -> ref.optionIdsOrEmpty().contains(opt))
					.count();
		};
	}

	private int minOf(CompiledRule rule) {
		Integer min = rule.paramsOrEmpty().min();
		return min == null ? 0 : min;
	}
}
