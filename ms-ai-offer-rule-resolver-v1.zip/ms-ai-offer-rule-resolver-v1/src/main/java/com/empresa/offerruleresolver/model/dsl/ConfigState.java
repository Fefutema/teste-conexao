package com.empresa.offerruleresolver.model.dsl;

import java.util.List;
import java.util.Map;

/**
 * Snapshot das escolhas do usuário num dado momento: para cada slot, a lista de
 * optionIds selecionados. É a entrada do {@link RuleEvaluator} e do sandbox.
 *
 * @param selectionsBySlot mapa slotId → optionIds selecionados
 */
public record ConfigState(Map<String, List<String>> selectionsBySlot) {

	public List<String> selected(String slotId) {
		return selectionsBySlot.getOrDefault(slotId, List.of());
	}

	public boolean isSlotEmpty(String slotId) {
		return selected(slotId).isEmpty();
	}
}
