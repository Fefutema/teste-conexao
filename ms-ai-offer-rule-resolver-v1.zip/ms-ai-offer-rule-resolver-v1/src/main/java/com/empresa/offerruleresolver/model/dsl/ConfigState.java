package com.empresa.offerruleresolver.model.dsl;

import java.util.Set;

/**
 * Snapshot das escolhas do usuário: o conjunto de produtos selecionados num dado
 * momento (por productId). É a entrada do {@link RuleEvaluator} e a "linha" da
 * tabela-verdade produzida pelo sandbox.
 *
 * <p>Indexado por produto (não por slot), porque no modelo do PDF a contagem de
 * uma regra é sobre um conjunto de produtos que pode cruzar grupos.
 */
public record ConfigState(Set<String> selectedProductIds) {

	public Set<String> selectedOrEmpty() {
		return selectedProductIds == null ? Set.of() : selectedProductIds;
	}
}
