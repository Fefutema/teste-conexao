package com.empresa.offerruleresolver.exception;

/**
 * Sinaliza que uma regra específica não pôde ser compilada de forma válida
 * (falhou na validação determinística após os retries, é insatisfazível, ou a
 * confiança ficou abaixo do limiar mínimo). Capturada pelo orquestrador para
 * produzir um resultado com status {@code REJECTED} — não derruba o lote inteiro.
 */
public class RuleRejectedException extends RuntimeException {

	private final String reason;

	public RuleRejectedException(String reason, String message) {
		super(message);
		this.reason = reason;
	}

	public String reason() {
		return this.reason;
	}
}
