package com.empresa.offerruleresolver.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * Configuração do serviço, ligada ao prefixo {@code offer-rule-resolver} no
 * application.yaml. Todos os limiares e chaves ficam aqui, sem números mágicos
 * espalhados pelo código.
 */
@ConfigurationProperties(prefix = "offer-rule-resolver")
public record CompilerProperties(
		@DefaultValue Translator translator,
		@DefaultValue Judge judge,
		@DefaultValue Confidence confidence,
		@DefaultValue Sandbox sandbox) {

	public record Translator(
			@DefaultValue("0.1") double temperature,
			@DefaultValue("2") int maxRetries,
			/** true = usa structured output nativo (JSON Schema estrito); exige deployment gpt-4o >= 2024-08-06. */
			@DefaultValue("false") boolean strictSchema) {
	}

	public record Judge(
			@DefaultValue("0.0") double temperature,
			@DefaultValue("false") boolean strictSchema) {
	}

	public record Confidence(
			@DefaultValue("0.90") double autoApproveThreshold,
			@DefaultValue("0.60") double reviewThreshold,
			/** Trava de segurança: quando true, TODA regra vai para revisão humana. */
			@DefaultValue("true") boolean forceHumanReview) {
	}

	public record Sandbox(
			@DefaultValue("64") int maxScenarios) {
	}
}
