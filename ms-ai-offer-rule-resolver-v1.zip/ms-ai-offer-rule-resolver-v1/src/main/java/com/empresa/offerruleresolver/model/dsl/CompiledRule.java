package com.empresa.offerruleresolver.model.dsl;

import java.util.List;

/**
 * Instância da DSL — o nó Rule do catálogo, no modelo do PDF.
 *
 * <p>Semântica (ver {@link RuleEvaluator}): a regra DISPARA quando a quantidade
 * de itens de ENTRADA selecionados cai na janela [inMin, inMax]; quando
 * disparada, VALIDA a quantidade de itens de SAÍDA selecionados contra a janela
 * [outMin, outMax], com a polaridade dada pelo {@link RuleType}.
 *
 * <p>As 7 portas lógicas do PDF são apenas tuplas destas janelas + tipo. A
 * ARIDADE de {@code input} distingue NOT (1 produto) de XNOR (2 produtos) mesmo
 * quando as janelas coincidem. {@code input}/{@code output} são productIds que
 * podem cruzar grupos da oferta.
 *
 * @param input             productIds de entrada (gatilho)
 * @param inMin,inMax       janela de disparo sobre a contagem de entrada
 * @param output            productIds de saída (efeito)
 * @param outMin,outMax     janela de validação sobre a contagem de saída
 * @param type              REQUIRES (saída deve cair na janela) | INCOMPATIBLE_WITH (não pode)
 * @param userFacingMessage mensagem curta em PT-BR para o cliente final
 */
public record CompiledRule(
		String id,
		RuleType type,
		List<String> input,
		int inMin,
		int inMax,
		List<String> output,
		int outMin,
		int outMax,
		String userFacingMessage) {

	public List<String> inputOrEmpty() {
		return input == null ? List.of() : input;
	}

	public List<String> outputOrEmpty() {
		return output == null ? List.of() : output;
	}
}
