package com.empresa.offerruleresolver.model.dsl;

import java.util.List;

/**
 * Instância da DSL v1 — o artefato que a LLM produz e que o engine de runtime
 * ({@code ms-offers-v1}) executará.
 *
 * <p><b>Fonte única da DSL:</b> este record + {@link RuleEvaluator} definem,
 * juntos, sintaxe e semântica. Ao evoluir a DSL, mexa aqui e no evaluator (e no
 * golden-set). O {@code dslVersion} habilita evolução v1→v2 sem quebrar regras
 * já salvas.
 *
 * @param id                identificador kebab-case (ex.: {@code "phone-required"})
 * @param dslVersion        versão da DSL (ex.: {@code "v1"})
 * @param type              operador
 * @param antecedents       condição (lado esquerdo)
 * @param consequents       efeito (lado direito); vazio para {@code ONE_OF}/{@code MIN_SELECTION}
 * @param params            parâmetros numéricos (só {@code MIN_SELECTION} usa {@code min})
 * @param userFacingMessage mensagem curta em PT-BR para o cliente final
 */
public record CompiledRule(
		String id,
		String dslVersion,
		RuleType type,
		List<SlotRef> antecedents,
		List<SlotRef> consequents,
		RuleParams params,
		String userFacingMessage) {

	public List<SlotRef> antecedentsOrEmpty() {
		return antecedents == null ? List.of() : antecedents;
	}

	public List<SlotRef> consequentsOrEmpty() {
		return consequents == null ? List.of() : consequents;
	}

	public RuleParams paramsOrEmpty() {
		return params == null ? RuleParams.empty() : params;
	}
}
