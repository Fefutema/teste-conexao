package com.empresa.offerruleresolver.repository;

import java.util.List;
import java.util.UUID;

import com.empresa.offerruleresolver.repository.entity.CompilationLog;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Camada repository — auditoria das compilações.
 */
@Repository
public interface CompilationLogRepository extends JpaRepository<CompilationLog, UUID> {

	List<CompilationLog> findByOfferId(String offerId);
}
