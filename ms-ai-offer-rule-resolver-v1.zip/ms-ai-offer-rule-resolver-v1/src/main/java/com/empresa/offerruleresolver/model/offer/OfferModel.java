package com.empresa.offerruleresolver.model.offer;

import java.util.List;
import java.util.Set;

/**
 * Modelo canônico interno da oferta (árvore 'contains' + arestas de cross-sell).
 * É o ÚNICO que a camada de service enxerga — o formato externo do JSON da oferta
 * nunca vaza para dentro do pipeline. Quando o JSON mudar, troca-se apenas o
 * {@link OfferParser}.
 *
 * @param root    a árvore da oferta (Root &gt; Group &gt; ... &gt; Product)
 * @param related cross-sell (compre-junto), fora do bundle e ignorado pelo sandbox
 */
public record OfferModel(OfferNode root, List<RelatedEdge> related) {

	public String offerId() {
		return root.id();
	}

	public Set<String> allProductIds() {
		return root.allProductIds();
	}

	public List<RelatedEdge> relatedOrEmpty() {
		return related == null ? List.of() : related;
	}
}
