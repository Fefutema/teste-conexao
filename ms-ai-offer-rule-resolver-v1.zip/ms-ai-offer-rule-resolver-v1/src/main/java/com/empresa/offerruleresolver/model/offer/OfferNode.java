package com.empresa.offerruleresolver.model.offer;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Nó recursivo da oferta (aresta 'contains' = a própria lista {@code children}),
 * de profundidade arbitrária (ex.: Root Bolota &gt; Group plano &gt; Group fisica
 * &gt; Product 30GB).
 *
 * <p><b>Duas cardinalidades distintas</b> (o PDF as separa):
 * <ul>
 *   <li>{@code selectMin/selectMax} — em ROOT/GROUP: quantos FILHOS podem ser
 *       selecionados dentro do agrupamento (ex.: plano 1..1, fisica 0..1).</li>
 *   <li>{@code qtyMin/qtyMax} — em PRODUCT: quantas UNIDADES do próprio produto
 *       (ex.: 30GB 1..2). Metadado da oferta; o sandbox v1 trata produto como
 *       selecionado/não-selecionado (binário).</li>
 * </ul>
 */
public record OfferNode(
		String id,
		NodeType type,
		int selectMin,
		int selectMax,
		int qtyMin,
		int qtyMax,
		List<OfferNode> children) {

	public boolean isProduct() {
		return type == NodeType.PRODUCT;
	}

	public List<OfferNode> childrenOrEmpty() {
		return children == null ? List.of() : children;
	}

	/** Todos os productIds da subárvore (walk recursivo). */
	public Set<String> allProductIds() {
		Set<String> acc = new LinkedHashSet<>();
		collect(this, acc);
		return acc;
	}

	private static void collect(OfferNode node, Set<String> acc) {
		if (node.isProduct()) {
			acc.add(node.id());
		}
		else {
			node.childrenOrEmpty().forEach(child -> collect(child, acc));
		}
	}
}
