package com.empresa.offerruleresolver.exception;

/**
 * Lançada quando o {@code offerJson} recebido não pode ser interpretado por
 * nenhum {@link com.empresa.offerruleresolver.model.offer.OfferParser}.
 */
public class OfferParseException extends RuntimeException {

	public OfferParseException(String message) {
		super(message);
	}

	public OfferParseException(String message, Throwable cause) {
		super(message, cause);
	}
}
