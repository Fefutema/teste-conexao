package com.empresa.offerruleresolver.model.dto;

import java.util.List;

/**
 * Resultado da simulação: a tabela-verdade + se a enumeração foi TRUNCADA (o teto
 * de cenários foi atingido). Sob truncamento a tabela é PARCIAL, então não se pode
 * concluir insatisfazibilidade a partir dela.
 *
 * @param scenarios cenários avaliados
 * @param truncated true se a enumeração parou no teto (tabela incompleta)
 */
public record TruthTable(List<SandboxScenario> scenarios, boolean truncated) {
}
