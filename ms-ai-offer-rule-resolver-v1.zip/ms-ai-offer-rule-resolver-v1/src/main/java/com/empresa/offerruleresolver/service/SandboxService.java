package com.empresa.offerruleresolver.service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.empresa.offerruleresolver.config.CompilerProperties;
import com.empresa.offerruleresolver.model.dsl.CompiledRule;
import com.empresa.offerruleresolver.model.dsl.ConfigState;
import com.empresa.offerruleresolver.model.dsl.RuleEvaluator;
import com.empresa.offerruleresolver.model.dto.SandboxScenario;
import com.empresa.offerruleresolver.model.offer.CatalogSlot;
import com.empresa.offerruleresolver.model.offer.OfferCatalog;

import org.springframework.stereotype.Service;

/**
 * Gera a TABELA-VERDADE de uma regra: avalia o comportamento contra cenários
 * sintéticos derivados da oferta. É o único jeito de verificar o comportamento
 * real antes de produção — e o artefato que humano e juíza revisam.
 *
 * <p>Enumeração: para N slots, cada slot pode estar "vazio" ou "preenchido com
 * sua primeira opção" → até 2^N cenários, limitados por
 * {@code sandbox.max-scenarios}.
 */
@Service
public class SandboxService {

	private final RuleEvaluator evaluator;

	private final CompilerProperties properties;

	public SandboxService(RuleEvaluator evaluator, CompilerProperties properties) {
		this.evaluator = evaluator;
		this.properties = properties;
	}

	public List<SandboxScenario> truthTable(CompiledRule rule, OfferCatalog catalog) {
		List<CatalogSlot> slots = catalog.slots();
		int n = slots.size();
		long fullSpace = (n >= 31) ? Integer.MAX_VALUE : (1L << n);
		long limit = Math.min(fullSpace, properties.sandbox().maxScenarios());

		List<SandboxScenario> scenarios = new ArrayList<>();
		for (long combo = 0; combo < limit; combo++) {
			Map<String, List<String>> state = new LinkedHashMap<>();
			for (int j = 0; j < n; j++) {
				CatalogSlot slot = slots.get(j);
				boolean filled = ((combo >> j) & 1L) == 1L;
				if (filled) {
					slot.firstOption().ifPresent(opt -> state.put(slot.id(), List.of(opt)));
				}
			}
			boolean valid = evaluator.isSatisfied(new ConfigState(state), rule);
			scenarios.add(new SandboxScenario(state, valid));
		}
		return scenarios;
	}

	/** Regra insatisfazível: nenhum cenário é válido. Deriva {@code UNSATISFIABLE} de graça. */
	public boolean isUnsatisfiable(List<SandboxScenario> scenarios) {
		return !scenarios.isEmpty() && scenarios.stream().noneMatch(SandboxScenario::valid);
	}
}
