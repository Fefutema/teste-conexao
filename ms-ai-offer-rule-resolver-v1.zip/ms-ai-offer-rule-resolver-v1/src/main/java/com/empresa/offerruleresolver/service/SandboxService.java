package com.empresa.offerruleresolver.service;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import com.empresa.offerruleresolver.config.CompilerProperties;
import com.empresa.offerruleresolver.model.dsl.CompiledRule;
import com.empresa.offerruleresolver.model.dsl.ConfigState;
import com.empresa.offerruleresolver.model.dsl.RuleEvaluator;
import com.empresa.offerruleresolver.model.dto.SandboxScenario;
import com.empresa.offerruleresolver.model.dto.TruthTable;
import com.empresa.offerruleresolver.model.offer.OfferModel;
import com.empresa.offerruleresolver.model.offer.OfferNode;

import org.springframework.stereotype.Service;

/**
 * Gera a TABELA-VERDADE de uma regra contra as configurações válidas da oferta.
 *
 * <p>Enumeração HIERÁRQUICA por COMBINAÇÕES: em cada agrupamento escolhe
 * subconjuntos de filhos de tamanho em [selectMin, selectMax] (n-escolhe-k, sobre
 * TODOS os filhos), recursivamente. Cada configuração é o conjunto de produtos
 * selecionados. Arestas 'related' (cross-sell) ficam de fora.
 *
 * <p>O teto {@code sandbox.max-scenarios} limita a explosão. Quando o teto é
 * atingido, a tabela é marcada como {@link TruthTable#truncated()} — e nesse caso
 * NÃO se conclui insatisfazibilidade (a enumeração é incompleta).
 */
@Service
public class SandboxService {

	private final RuleEvaluator evaluator;

	private final CompilerProperties properties;

	public SandboxService(RuleEvaluator evaluator, CompilerProperties properties) {
		this.evaluator = evaluator;
		this.properties = properties;
	}

	public TruthTable truthTable(CompiledRule rule, OfferModel offer) {
		int cap = Math.max(1, properties.sandbox().maxScenarios());
		boolean[] truncated = { false };
		List<Set<String>> configs = enumerate(offer.root(), cap, truncated);

		List<SandboxScenario> scenarios = new ArrayList<>(configs.size());
		for (Set<String> config : configs) {
			boolean valid = this.evaluator.isSatisfied(new ConfigState(config), rule);
			scenarios.add(new SandboxScenario(config, valid));
		}
		return new TruthTable(scenarios, truncated[0]);
	}

	/**
	 * Regra insatisfazível: nenhuma configuração válida a satisfaz. CONSERVADOR sob
	 * truncamento — se a tabela é parcial, retorna {@code false} (indeterminado),
	 * nunca rejeitando uma regra por uma enumeração incompleta.
	 */
	public boolean isUnsatisfiable(TruthTable table) {
		if (table.truncated()) {
			return false;
		}
		return !table.scenarios().isEmpty() && table.scenarios().stream().noneMatch(SandboxScenario::valid);
	}

	/** Configurações válidas (conjuntos de produtos selecionados) da subárvore. */
	private List<Set<String>> enumerate(OfferNode node, int cap, boolean[] truncated) {
		if (node.isProduct()) {
			List<Set<String>> single = new ArrayList<>(1);
			single.add(Set.of(node.id()));
			return single;
		}

		List<OfferNode> children = node.childrenOrEmpty();
		int n = children.size();
		int maxSel = Math.min(node.selectMax(), n);
		int minSel = Math.max(0, Math.min(node.selectMin(), maxSel));

		Set<Set<String>> result = new LinkedHashSet<>();
		for (int k = minSel; k <= maxSel && result.size() < cap; k++) {
			collectCombos(children, k, cap, truncated, result);
		}
		if (result.isEmpty()) {
			result.add(Set.of()); // selectMin == 0: nenhum filho selecionado é válido
		}
		return new ArrayList<>(result);
	}

	/** Gera combinações de {@code k} filhos (lex order, com corte pelo cap) e as expande. */
	private void collectCombos(List<OfferNode> children, int k, int cap, boolean[] truncated,
			Set<Set<String>> result) {
		int n = children.size();
		if (k > n) {
			return;
		}
		int[] idx = new int[k];
		for (int i = 0; i < k; i++) {
			idx[i] = i;
		}
		while (true) {
			List<OfferNode> combo = new ArrayList<>(k);
			for (int i : idx) {
				combo.add(children.get(i));
			}
			for (Set<String> union : cartesianUnion(combo, cap, truncated)) {
				result.add(union);
				if (result.size() >= cap) {
					truncated[0] = true;
					return;
				}
			}
			// próxima combinação (algoritmo padrão de índices)
			int i = k - 1;
			while (i >= 0 && idx[i] == n - k + i) {
				i--;
			}
			if (i < 0) {
				break;
			}
			idx[i]++;
			for (int j = i + 1; j < k; j++) {
				idx[j] = idx[j - 1] + 1;
			}
		}
	}

	/** Produto cartesiano das configurações de cada filho escolhido, unindo os conjuntos. */
	private List<Set<String>> cartesianUnion(List<OfferNode> chosen, int cap, boolean[] truncated) {
		List<Set<String>> acc = new ArrayList<>();
		acc.add(Set.of());
		for (OfferNode child : chosen) {
			List<Set<String>> childConfigs = enumerate(child, cap, truncated);
			List<Set<String>> next = new ArrayList<>();
			for (Set<String> base : acc) {
				for (Set<String> cc : childConfigs) {
					Set<String> union = new LinkedHashSet<>(base);
					union.addAll(cc);
					next.add(union);
					if (next.size() >= cap) {
						truncated[0] = true;
						break;
					}
				}
				if (next.size() >= cap) {
					break;
				}
			}
			acc = next;
		}
		return acc;
	}
}
