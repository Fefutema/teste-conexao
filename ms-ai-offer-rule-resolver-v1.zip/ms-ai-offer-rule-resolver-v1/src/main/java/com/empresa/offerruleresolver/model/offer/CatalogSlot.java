package com.empresa.offerruleresolver.model.offer;

import java.util.List;
import java.util.Optional;

/**
 * Slot do modelo canônico interno — o mínimo que o pipeline precisa saber sobre
 * a oferta: id, cardinalidade e as opções elegíveis.
 */
public record CatalogSlot(String id, int minQty, int maxQty, List<String> optionIds) {

	public boolean hasOption(String optionId) {
		return optionIds != null && optionIds.contains(optionId);
	}

	/** Primeira opção do slot — usada pelo sandbox como representante ao "preencher" o slot. */
	public Optional<String> firstOption() {
		return optionIds == null || optionIds.isEmpty() ? Optional.empty() : Optional.of(optionIds.get(0));
	}
}
