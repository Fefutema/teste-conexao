# Contrato semântico com o engine de runtime

> **Passo 3 do MVP.** Este documento define a **semântica exata** de uma regra e
> explica **como garantir que o `RuleEvaluator` deste serviço calcule EXATAMENTE
> o mesmo que o engine que executa as ofertas na loja**. Sem essa paridade, a
> tabela-verdade aprovada aqui é uma mentira.

---

## 1. O problema (por que isso é crítico)

Este microsserviço **compila e valida** regras. Quem **executa** a regra em
runtime (quando o cliente monta a oferta na loja) é **outro componente** — vamos
chamá-lo de **engine de runtime** (ex.: `ms-offers-v1` ou o configurador da
loja). Ele **não existe neste repositório**; é uma dependência da sua arquitetura.

O serviço aprova uma regra mostrando ao revisor uma **tabela-verdade** — gerada
pelo nosso [`RuleEvaluator`](src/main/java/com/empresa/offerruleresolver/model/dsl/RuleEvaluator.java).
Se o engine de runtime interpretar a mesma regra **de forma diferente**, então:

- o revisor aprova achando que a regra faz X;
- em produção a regra faz Y;
- resultado: **oferta inválida vendida = prejuízo**, e o pior tipo de bug —
  silencioso, sem erro, só comportamento errado.

> **Invariante que precisa valer sempre:**
> `RuleEvaluator.isSatisfied(seleção, regra)` (aqui) **≡** `engine.isSatisfied(seleção, regra)` (runtime),
> para **toda** regra e **toda** seleção.

---

## 2. A especificação canônica da semântica (a fonte da verdade)

Esta é a definição que **ambas** as implementações devem obedecer, ao pé da letra.

### 2.1. Modelo da regra

Uma regra é a tupla:

```
(input: conjunto de productIds, inMin: int, inMax: int,
 output: conjunto de productIds, outMin: int, outMax: int,
 type: REQUIRES | INCOMPATIBLE_WITH)
```

A **seleção** do usuário é um **conjunto** de productIds selecionados.

### 2.2. Algoritmo (pseudocódigo normativo)

```
função isSatisfied(selecionados: Set<produto>, regra): boolean
    in  = |{ p ∈ regra.input  : p ∈ selecionados }|     # contagem de DISTINTOS
    disparou = (in >= regra.inMin) E (in <= regra.inMax)
    se NÃO disparou:
        retorne true                                     # vacuamente satisfeita
    out = |{ p ∈ regra.output : p ∈ selecionados }|      # contagem de DISTINTOS
    dentroDaJanela = (out >= regra.outMin) E (out <= regra.outMax)
    se regra.type == REQUIRES:
        retorne dentroDaJanela                            # a saída DEVE cair na janela
    senão: # INCOMPATIBLE_WITH
        retorne NÃO dentroDaJanela                        # a saída NÃO pode cair na janela
```

### 2.3. A implementação atual (Java) — a referência

Trecho de [`RuleEvaluator.java`](src/main/java/com/empresa/offerruleresolver/model/dsl/RuleEvaluator.java):

```java
public boolean isSatisfied(ConfigState state, CompiledRule rule) {
    Set<String> selected = state.selectedOrEmpty();

    int in = countSelected(rule.inputOrEmpty(), selected);
    boolean triggered = in >= rule.inMin() && in <= rule.inMax();
    if (!triggered) {
        return true; // vacuamente satisfeita
    }
    int out = countSelected(rule.outputOrEmpty(), selected);
    boolean outInWindow = out >= rule.outMin() && out <= rule.outMax();

    return switch (rule.type()) {
        case REQUIRES          -> outInWindow;
        case INCOMPATIBLE_WITH -> !outInWindow;
    };
}
// countSelected usa .distinct(): conta PRODUTOS distintos, não posições da lista.
```

### 2.4. Regras finas que DEVEM concordar (as pegadinhas)

Estas são as decisões onde uma reimplementação costuma divergir. **Fixe-as por
escrito e teste-as** (seção 4):

| # | Decisão | Definição normativa |
|---|---|---|
| A | **Vacuidade** | Regra que **não dispara** é `true` (satisfeita), nunca `false`. |
| B | **Contagem** | Conta **produtos distintos** selecionados (não unidades, não posições da lista). |
| C | **`INCOMPATIBLE_WITH`** | Satisfeita quando a saída está **FORA** de `[outMin,outMax]`. Com `out 1..1`, isso vira "saída == 0". Não hardcode `== 0`: use a janela. |
| D | **Janela inclusiva** | `[min, max]` é **fechado** dos dois lados (`>=` e `<=`). |
| E | **Entrada vazia** | Regra sem gatilho não existe: `inMin >= 1` é exigido pelo validador. O engine pode assumir isso. |
| F | **Quantidade (unidades)** | O modelo v1 conta **presença** de produto (selecionado/não), **não unidades** (`qtyMin/qtyMax`). Se o engine contar unidades, **diverge** — alinhar antes. |
| G | **`related` (cross-sell)** | Produtos `related` estão **fora do bundle** e **não** entram na contagem de nenhuma regra. |

---

## 3. Como garantir a paridade — 3 estratégias (da melhor para a aceitável)

### Estratégia 1 (RECOMENDADA) — Biblioteca compartilhada

Se o engine de runtime é **JVM** (Java/Kotlin), a paridade fica **garantida por
construção**: extraia o pacote `model.dsl` para um artefato próprio e faça os dois
serviços dependerem dele.

**O que extrair** (é auto-contido, sem Spring exceto uma anotação removível):
- `CompiledRule`, `RuleType`, `ConfigState`, `RuleEvaluator`.

**Como fazer:**

1. Crie um módulo/artefato `offer-rule-dsl` (Maven), versionado:
   ```xml
   <groupId>com.empresa</groupId>
   <artifactId>offer-rule-dsl</artifactId>
   <version>1.0.0</version>
   ```
   Mova as 4 classes para lá. Remova o `@Component` do `RuleEvaluator` (ou deixe
   o Spring opcional) para o artefato não arrastar dependência de framework.

2. Este microsserviço passa a **depender** dele:
   ```xml
   <dependency>
     <groupId>com.empresa</groupId>
     <artifactId>offer-rule-dsl</artifactId>
     <version>1.0.0</version>
   </dependency>
   ```
   e registra o bean:
   ```java
   @Bean RuleEvaluator ruleEvaluator() { return new RuleEvaluator(); }
   ```

3. O **engine de runtime** depende do **mesmo** artefato e usa o **mesmo**
   `RuleEvaluator.isSatisfied(...)` para executar a regra.

➡️ **Divergência = 0**, porque é literalmente o mesmo código. Evolução da DSL vira
uma nova versão do artefato, adotada pelos dois lados de forma coordenada.

> **Cuidado:** só publique uma nova versão do `offer-rule-dsl` quando os dois
> consumidores puderem adotá-la. Uma mudança de semântica é uma mudança de
> contrato.

### Estratégia 2 — Vetores de contrato compartilhados (se o engine NÃO é JVM)

Se o engine está em outra linguagem (Node, Go, C#...), você não compartilha código
— então compartilha **casos de teste**. Um arquivo **neutro** de vetores
`(regra, seleção) → esperado` que **os dois lados** rodam no CI.

Guarde-o num repositório comum (ou publique como artefato). Formato sugerido
`semantics-contract.json`:

```json
{
  "dslVersion": "1",
  "description": "Contrato semântico da regra de oferta. Ambos os lados DEVEM passar.",
  "vectors": [
    { "name": "OR: dispara e saida presente => valido",
      "rule": { "type": "REQUIRES", "input": ["20GB","30GB"], "inMin": 1, "inMax": 2,
                "output": ["iphone-branco"], "outMin": 1, "outMax": 1 },
      "selected": ["20GB","iphone-branco"], "expected": true },

    { "name": "OR: dispara e saida ausente => invalido",
      "rule": { "type": "REQUIRES", "input": ["20GB","30GB"], "inMin": 1, "inMax": 2,
                "output": ["iphone-branco"], "outMin": 1, "outMax": 1 },
      "selected": ["20GB","iphone-preto"], "expected": false },

    { "name": "OR: nao dispara => vacuamente valido",
      "rule": { "type": "REQUIRES", "input": ["20GB","30GB"], "inMin": 1, "inMax": 2,
                "output": ["iphone-branco"], "outMin": 1, "outMax": 1 },
      "selected": ["40GB","iphone-preto"], "expected": true },

    { "name": "AND: precisa dos DOIS para disparar",
      "rule": { "type": "REQUIRES", "input": ["20GB","30GB"], "inMin": 2, "inMax": 2,
                "output": ["iphone-branco"], "outMin": 1, "outMax": 1 },
      "selected": ["20GB","iphone-preto"], "expected": true },
    { "name": "AND: os dois selecionados, saida ausente => invalido",
      "rule": { "type": "REQUIRES", "input": ["20GB","30GB"], "inMin": 2, "inMax": 2,
                "output": ["iphone-branco"], "outMin": 1, "outMax": 1 },
      "selected": ["20GB","30GB"], "expected": false },

    { "name": "XOR: exatamente um dispara",
      "rule": { "type": "REQUIRES", "input": ["20GB","30GB"], "inMin": 1, "inMax": 1,
                "output": ["iphone-branco"], "outMin": 1, "outMax": 1 },
      "selected": ["20GB","iphone-branco"], "expected": true },
    { "name": "XOR: os dois selecionados NAO dispara (vacuo)",
      "rule": { "type": "REQUIRES", "input": ["20GB","30GB"], "inMin": 1, "inMax": 1,
                "output": ["iphone-branco"], "outMin": 1, "outMax": 1 },
      "selected": ["20GB","30GB"], "expected": true },

    { "name": "INCOMPATIBLE_WITH (NOR): dispara e saida presente => proibido",
      "rule": { "type": "INCOMPATIBLE_WITH", "input": ["20GB","30GB"], "inMin": 1, "inMax": 2,
                "output": ["iphone-branco"], "outMin": 1, "outMax": 1 },
      "selected": ["20GB","iphone-branco"], "expected": false },
    { "name": "INCOMPATIBLE_WITH (NOR): dispara e saida ausente => ok",
      "rule": { "type": "INCOMPATIBLE_WITH", "input": ["20GB","30GB"], "inMin": 1, "inMax": 2,
                "output": ["iphone-branco"], "outMin": 1, "outMax": 1 },
      "selected": ["20GB","iphone-preto"], "expected": true },

    { "name": "NOT vs XNOR: aridade da entrada importa (input unario dispara com {20GB,30GB,branco})",
      "rule": { "type": "INCOMPATIBLE_WITH", "input": ["50GB"], "inMin": 1, "inMax": 1,
                "output": ["iphone-branco"], "outMin": 1, "outMax": 1 },
      "selected": ["50GB","iphone-branco"], "expected": false },

    { "name": "janela de saida larga (out 2..3): REQUIRES exige >=2",
      "rule": { "type": "REQUIRES", "input": ["fisica-flag"], "inMin": 1, "inMax": 1,
                "output": ["netflix","hbo","prime"], "outMin": 2, "outMax": 3 },
      "selected": ["fisica-flag","netflix"], "expected": false },
    { "name": "janela de saida larga (out 2..3): dois streamings => valido",
      "rule": { "type": "REQUIRES", "input": ["fisica-flag"], "inMin": 1, "inMax": 1,
                "output": ["netflix","hbo","prime"], "outMin": 2, "outMax": 3 },
      "selected": ["fisica-flag","netflix","hbo"], "expected": true },

    { "name": "contagem DISTINTA: id repetido no input nao infla",
      "rule": { "type": "REQUIRES", "input": ["20GB","20GB"], "inMin": 2, "inMax": 2,
                "output": ["iphone-branco"], "outMin": 1, "outMax": 1 },
      "selected": ["20GB","iphone-branco"], "expected": true,
      "note": "in distinto = 1, fora de [2,2] => nao dispara => vacuamente true" }
  ]
}
```

Cada lado implementa um teste que lê esse arquivo e verifica
`isSatisfied(vector.selected, vector.rule) == vector.expected`. Se qualquer vetor
falhar em qualquer lado, **quebra o build**. O arquivo é a **fonte única do
contrato**; qualquer mudança de semântica passa por PR nele.

> Dica: gere os vetores a partir do golden-set + o próprio `SandboxService` deste
> serviço, para os vetores refletirem a semântica de referência automaticamente.

### Estratégia 3 — Teste de contrato dirigido pelo consumidor (se há fronteira de API)

Se o engine expõe a execução por API (ex.: "dado esta oferta + estas regras +
esta seleção, é válido?"), use **contract testing** (Pact / Spring Cloud
Contract): este serviço publica o contrato (os vetores da Estratégia 2 como
interações), e o CI do engine verifica que ele honra o contrato. É a Estratégia 2
formalizada num handshake entre repositórios.

---

## 4. Runbook — verificar paridade antes de cada release

Independentemente da estratégia, rode este check **antes de liberar** qualquer
mudança que toque a semântica (DSL, evaluator, ou o engine):

1. **Congele os vetores.** `semantics-contract.json` (ou o artefato compartilhado)
   é a referência.
2. **Rode os vetores nos DOIS lados.**
   - Aqui: um teste JUnit que carrega o JSON e chama `RuleEvaluator.isSatisfied`.
   - No engine: o teste equivalente na linguagem dele.
3. **Ambos verdes ⇒ pode liberar.** Qualquer vermelho ⇒ **para o release** e
   alinha a divergência antes.
4. **Ao evoluir a DSL** (novo operador, nova janela): adicione vetores **antes** de
   mudar o código, e só suba a versão do contrato quando os dois lados adotarem.

### Esqueleto do teste (aqui, JUnit) para a Estratégia 2

```java
// lê semantics-contract.json e valida cada vetor contra o RuleEvaluator local
@Test
void honraContratoSemantico() throws Exception {
    var mapper = new com.fasterxml.jackson.databind.ObjectMapper();
    var contract = mapper.readTree(new java.io.File("semantics-contract.json"));
    var evaluator = new RuleEvaluator();
    for (var v : contract.get("vectors")) {
        var r = v.get("rule");
        var rule = new CompiledRule(
            v.get("name").asText(),
            RuleType.valueOf(r.get("type").asText()),
            toList(r.get("input")),  r.get("inMin").asInt(),  r.get("inMax").asInt(),
            toList(r.get("output")), r.get("outMin").asInt(), r.get("outMax").asInt(),
            "contract");
        var selected = new java.util.HashSet<String>();
        v.get("selected").forEach(n -> selected.add(n.asText()));
        boolean actual = evaluator.isSatisfied(new ConfigState(selected), rule);
        org.assertj.core.api.Assertions.assertThat(actual)
            .as(v.get("name").asText())
            .isEqualTo(v.get("expected").asBoolean());
    }
}
```

---

## 5. Alternativa de fundo: e se o engine JÁ tem um formato de regra?

Se o `ms-offers-v1` (ou o configurador) **já** executa regras num formato próprio,
a decisão mais forte **não** é reconciliar duas semânticas — é **compilar direto
para o formato dele**:

- Trocar o alvo do tradutor/`CompiledRule` para o formato de regra do engine.
- O `RuleEvaluator` local passa a ser um **espelho** exato da execução do engine
  (idealmente, a própria lib dele — Estratégia 1).

Assim você elimina a tradução dupla (nossa DSL → formato do engine) e a superfície
de divergência. **Antes de investir na DSL própria, confirme se o engine já tem
formato** — essa é a primeira pergunta a fechar com o time de runtime.

---

## 6. Resumo (o que fazer, em ordem)

1. **Pergunte ao time do engine:** ele já tem formato de regra? Se sim → considere
   compilar pra ele (seção 5).
2. **Fixe a semântica** desta DSL por escrito (seção 2) — especialmente as
   pegadinhas A–G.
3. **Escolha a estratégia de paridade:**
   - Engine é JVM → **Estratégia 1** (lib `offer-rule-dsl` compartilhada).
   - Engine é outra linguagem → **Estratégia 2** (`semantics-contract.json`).
   - Há fronteira de API → **Estratégia 3** (contract testing).
4. **Rode o runbook (seção 4) antes de cada release.**
5. **Nunca** aprove uma mudança de semântica sem os vetores verdes nos dois lados.
