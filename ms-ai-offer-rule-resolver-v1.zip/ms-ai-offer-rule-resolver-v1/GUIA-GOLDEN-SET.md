# Guia do Golden-Set — a especificação real da DSL

> **Passo 2 do MVP.** Este documento explica, em detalhe, **como escrever o
> golden-set** (o conjunto de pares "frase em PT-BR → regra técnica esperada"),
> por que ele é a peça mais importante do serviço, e como montá-lo **junto com o
> negócio antes de escrever código de regra**.

---

## 1. O que é e por que é a coisa mais importante

O golden-set é um arquivo com pares assim:

```yaml
- id: exemplo
  nl: "Se selecionei 20GB ou 30GB então devo selecionar o iPhone Branco."
  expected:
    type: REQUIRES
    input: [20GB, 30GB]
    inMin: 1
    inMax: 2
    output: [iphone-branco]
    outMin: 1
    outMax: 1
    userFacingMessage: "Com 20GB ou 30GB, o iPhone Branco é obrigatório."
```

Ele **não é documentação opcional**. Ele é a **especificação executável da DSL**:
é a fonte que define, com exemplos concretos, o que cada frase de negócio deve
virar. Se a especificação estiver errada aqui, o serviço inteiro compila regras
erradas com confiança — e "regra errada em produção = oferta inválida vendida =
prejuízo".

### Os 3 papéis do golden-set (o mesmo arquivo serve para os três)

| Papel | Como | Quando |
|---|---|---|
| **1. Few-shot** | O `ContextBuilder` lê o arquivo **cru** e injeta os exemplos no prompt do tradutor | Toda compilação (runtime) |
| **2. Eval / gate de regressão** | Um teste roda o golden-set contra a LLM real e mede acurácia; bloqueia PR que piora | CI (Fase 2) |
| **3. Documentação viva** | É o contrato legível entre negócio e engenharia sobre o que cada frase significa | Sempre |

Onde fica: [`src/main/resources/eval/golden-set.yaml`](src/main/resources/eval/golden-set.yaml).
Como é lido: [`ContextBuilder.java`](src/main/java/com/empresa/offerruleresolver/service/ContextBuilder.java)
o carrega como **texto bruto** e o cola no prompt (sem parser de YAML — a LLM lê
YAML muito bem). Na Fase 2, um teste de eval vai **parsear** o mesmo arquivo para
comparar o resultado da LLM com o `expected`.

---

## 2. A oferta de referência (usada em todos os exemplos deste guia)

Todos os exemplos abaixo assumem esta oferta "Bolota" (é o mesmo shape que o
`OfferJsonParser` espera — ver [`fixtures/offers/bolota.json`](src/test/resources/fixtures/offers/bolota.json)):

```
Bolota (Root, seleciona 2 de 2)
├── plano (Group, seleciona 1 de 1)
│   ├── fisica  (Group, seleciona 1 de 1)
│   │   ├── 20GB      (Product)
│   │   └── 30GB      (Product)
│   └── juridica (Group, seleciona 1 de 1)
│       ├── 40GB      (Product)
│       └── 50GB      (Product)
└── aparelho (Group, seleciona 1 de 1)
    ├── iphone-preto  (Product)
    └── iphone-branco (Product)

related: carregador-usb-c → iphone-branco   (compre-junto, FORA do bundle)
```

**productIds válidos:** `20GB, 30GB, 40GB, 50GB, iphone-preto, iphone-branco`.
O `carregador-usb-c` é `related` (cross-sell), **não** entra em regra nem no bundle.

---

## 3. Formato do arquivo, campo a campo

Cada item do YAML tem `id`, `nl` (a frase) e `expected` (a regra técnica — um
[`CompiledRule`](src/main/java/com/empresa/offerruleresolver/model/dsl/CompiledRule.java)).

```yaml
- id: streaming-or-requires-branco   # identificador do EXEMPLO (não da regra)
  nl: "..."                          # a frase de negócio, EXATAMENTE como o usuário escreveria
  expected:
    id: plan-or-requires-branco      # id da REGRA (kebab-case, descritivo)
    type: REQUIRES                   # REQUIRES | INCOMPATIBLE_WITH
    input:  [20GB, 30GB]             # conjunto de produtos de ENTRADA (o gatilho)
    inMin:  1                        # dispara se a contagem de entrada selecionada >= inMin
    inMax:  2                        # ...e <= inMax
    output: [iphone-branco]          # conjunto de produtos de SAÍDA (o efeito)
    outMin: 1                        # valida a contagem de saída selecionada contra [outMin, outMax]
    outMax: 1
    userFacingMessage: "..."         # mensagem curta em PT-BR pro cliente final
```

### Como a regra é lida (a semântica exata)

> **DISPARA** quando `contagem(produtos de input selecionados) ∈ [inMin, inMax]`.
> **VALIDA** (só quando dispara): olha `contagem(produtos de output selecionados)`:
> - `REQUIRES` → satisfeita se a contagem de saída **está** em `[outMin, outMax]`.
> - `INCOMPATIBLE_WITH` → satisfeita se a contagem de saída **NÃO está** em `[outMin, outMax]`.
> Quando **não dispara**, a regra é **vacuamente satisfeita** (não restringe nada).

Isso é exatamente o que [`RuleEvaluator`](src/main/java/com/empresa/offerruleresolver/model/dsl/RuleEvaluator.java)
implementa. O documento [`CONTRATO-SEMANTICO-RUNTIME.md`](CONTRATO-SEMANTICO-RUNTIME.md)
detalha essa semântica como contrato com o engine de execução.

---

## 4. Como montar o golden-set COM o negócio (o processo)

**Regra de ouro: escreva o golden-set antes de codar regra nova.** É uma sessão
de trabalho, não uma tarefa de dev solo.

### Passo a passo do workshop

1. **Reúna** 1 pessoa de negócio (que escreve ofertas), 1 dev e, se possível, 1
   pessoa que conheça o engine de runtime.
2. **Pegue 3 ofertas reais já existentes** e liste as regras que elas têm hoje
   (mesmo que estejam em código ou numa planilha).
3. Para **cada regra real**, escreva:
   - a **frase** como o usuário de negócio a escreveria (`nl`);
   - a **regra técnica esperada** (`expected`), preenchida a quatro mãos.
4. **Desenhe a tabela-verdade na mão** para 2–3 regras (ver seção 6) e confirme
   com o negócio: "é ISSO que a regra deve fazer?". É aqui que ambiguidades
   aparecem.
5. **Cubra os casos difíceis** de propósito (seção 5.4): negação, "apenas um",
   "se não... então", sinônimos, e pelo menos **uma regra impossível** (que deve
   ser rejeitada).
6. **Valide a DSL**: se as 3 ofertas reais **cabem** na DSL, ela está boa. Se
   alguma regra real não cabe, **ajuste a DSL antes de codar** — não force.

> Meta inicial: **12–15 exemplos** cobrindo as dimensões da seção 7. Para o gate
> de eval (Fase 2) ser estatisticamente útil, cresça para **50+**.

---

## 5. Catálogo de exemplos

### 5.1. As 7 portas lógicas (o núcleo)

Todas usam entrada `{A,B}` (ou `{A}` no NOT) e saída `{C}`. Aqui, A=`20GB`,
B=`30GB`, C=`iphone-branco`.

```yaml
# AND — "se A E B"
- id: and-requires
  nl: "Se o cliente selecionar 20GB e 30GB, então o iPhone Branco é obrigatório."
  expected:
    id: and-requires-branco
    type: REQUIRES
    input: [20GB, 30GB]
    inMin: 2
    inMax: 2
    output: [iphone-branco]
    outMin: 1
    outMax: 1
    userFacingMessage: "Com 20GB e 30GB, o iPhone Branco é obrigatório."

# NAND — "se A E B, então NÃO C"
- id: nand-incompatible
  nl: "Se o cliente selecionar 20GB e 30GB, então não pode levar o iPhone Branco."
  expected:
    id: and-incompatible-branco
    type: INCOMPATIBLE_WITH
    input: [20GB, 30GB]
    inMin: 2
    inMax: 2
    output: [iphone-branco]
    outMin: 1
    outMax: 1
    userFacingMessage: "Com 20GB e 30GB, o iPhone Branco não está disponível."

# OR — "se A OU B"
- id: or-requires
  nl: "Se selecionar 20GB ou 30GB, então deve levar o iPhone Branco."
  expected:
    id: or-requires-branco
    type: REQUIRES
    input: [20GB, 30GB]
    inMin: 1
    inMax: 2
    output: [iphone-branco]
    outMin: 1
    outMax: 1
    userFacingMessage: "Com 20GB ou 30GB, o iPhone Branco é obrigatório."

# NOR — "se A OU B, então NÃO C"
- id: nor-incompatible
  nl: "Se selecionar 20GB ou 30GB, então não pode levar o iPhone Branco."
  expected:
    id: or-incompatible-branco
    type: INCOMPATIBLE_WITH
    input: [20GB, 30GB]
    inMin: 1
    inMax: 2
    output: [iphone-branco]
    outMin: 1
    outMax: 1
    userFacingMessage: "Com 20GB ou 30GB, o iPhone Branco não está disponível."

# XOR — "se EXATAMENTE UM de A,B"  (a entrada 1..1 sobre 2 produtos)
- id: xor-requires
  nl: "Se selecionar exatamente um entre 20GB e 30GB, então deve levar o iPhone Branco."
  expected:
    id: xor-requires-branco
    type: REQUIRES
    input: [20GB, 30GB]
    inMin: 1
    inMax: 1
    output: [iphone-branco]
    outMin: 1
    outMax: 1
    userFacingMessage: "Escolhendo só um dos planos, o iPhone Branco é obrigatório."

# XNOR — "se exatamente um de A,B, então NÃO C"
- id: xnor-incompatible
  nl: "Se selecionar exatamente um entre 20GB e 30GB, então não pode levar o iPhone Branco."
  expected:
    id: xor-incompatible-branco
    type: INCOMPATIBLE_WITH
    input: [20GB, 30GB]
    inMin: 1
    inMax: 1
    output: [iphone-branco]
    outMin: 1
    outMax: 1
    userFacingMessage: "Escolhendo só um dos planos, o iPhone Branco não está disponível."

# NOT — entrada UNÁRIA (1 produto).  A tupla de janelas é idêntica à do XNOR;
#       o que muda é a ARIDADE da entrada ({A} em vez de {A,B}).
- id: not-incompatible
  nl: "Se selecionar 50GB, então não pode levar o iPhone Branco."
  expected:
    id: fifty-incompatible-branco
    type: INCOMPATIBLE_WITH
    input: [50GB]
    inMin: 1
    inMax: 1
    output: [iphone-branco]
    outMin: 1
    outMax: 1
    userFacingMessage: "Com 50GB, o iPhone Branco não está disponível."
```

> **Cheat-sheet das portas** (input `{A,B}`, output `{C}`):
>
> | Porta | inMin..inMax | type |
> |---|---|---|
> | AND  | 2..2 | REQUIRES |
> | NAND | 2..2 | INCOMPATIBLE_WITH |
> | OR   | 1..2 | REQUIRES |
> | NOR  | 1..2 | INCOMPATIBLE_WITH |
> | XOR  | 1..1 | REQUIRES |
> | XNOR | 1..1 | INCOMPATIBLE_WITH |
> | NOT  | 1..1 (input `{A}`) | INCOMPATIBLE_WITH |

### 5.2. Janelas de saída além de 1..1

A saída **não precisa** ser 1..1. A janela vale para **qualquer** contagem.

```yaml
# "escolha PELO MENOS 2 acessórios de streaming"
- id: min-2-streamings
  nl: "Se levar o plano físico, deve escolher pelo menos 2 entre Netflix, HBO e Prime."
  expected:
    id: fisica-requires-2-streamings
    type: REQUIRES
    input:  [fisica-flag]          # (produto/flag que representa "plano físico")
    inMin:  1
    inMax:  1
    output: [netflix, hbo, prime]
    outMin: 2                       # pelo menos 2...
    outMax: 3                       # ...até 3 (o total)
    userFacingMessage: "No plano físico, escolha pelo menos 2 streamings."

# "no MÁXIMO 1 streaming"  (out 0..1)
- id: at-most-1-streaming
  nl: "No plano jurídico, pode levar no máximo um streaming."
  expected:
    id: juridica-at-most-1-streaming
    type: REQUIRES
    input:  [juridica-flag]
    inMin:  1
    inMax:  1
    output: [netflix, hbo, prime]
    outMin: 0                       # 0 ou 1 é válido
    outMax: 1
    userFacingMessage: "No plano jurídico, escolha no máximo um streaming."
```

> A janela de saída também é usada no `INCOMPATIBLE_WITH`: ela descreve a **zona
> proibida**. Ex.: `INCOMPATIBLE_WITH` com `out 2..3` significa "quando disparada,
> **não pode** ter entre 2 e 3 itens de saída selecionados".

### 5.3. Múltiplos antecedentes (aridade 3+)

```yaml
# "se levar 20GB, 30GB e 40GB (os três)"  → in 3..3 (AND de 3)
- id: three-and
  nl: "Se levar 20GB, 30GB e 40GB, então o iPhone Preto é obrigatório."
  expected:
    id: three-plans-require-preto
    type: REQUIRES
    input:  [20GB, 30GB, 40GB]
    inMin:  3
    inMax:  3
    output: [iphone-preto]
    outMin: 1
    outMax: 1
    userFacingMessage: "Com 20GB, 30GB e 40GB, o iPhone Preto é obrigatório."

# "se levar pelo menos 2 dos três planos"  → in 2..3
- id: at-least-2-of-3
  nl: "Se levar pelo menos dois entre 20GB, 30GB e 40GB, então o iPhone Branco é obrigatório."
  expected:
    id: two-of-three-require-branco
    type: REQUIRES
    input:  [20GB, 30GB, 40GB]
    inMin:  2
    inMax:  3
    output: [iphone-branco]
    outMin: 1
    outMax: 1
    userFacingMessage: "Levando dois ou mais planos, o iPhone Branco é obrigatório."
```

### 5.4. Casos DIFÍCEIS (escreva estes de propósito)

Estes são os que separam um golden-set bom de um raso. Anote **por que** cada um é
o que é — vira decisão de produto.

```yaml
# AMBIGUIDADE: "apenas um" — é "exatamente um" (in 1..1) ou "no máximo um" (0..1)?
# ⚠️ DECIDA COM O NEGÓCIO E MARQUE. Aqui interpretamos como "no máximo um".
- id: ambiguity-apenas-um
  nl: "Se levar o plano físico, escolha apenas um streaming."
  expected:
    id: fisica-at-most-1-streaming
    type: REQUIRES
    input:  [fisica-flag]
    inMin:  1
    inMax:  1
    output: [netflix, hbo, prime]
    outMin: 0        # "apenas um" lido como AT-MOST-1 (0 ou 1). Se o negócio quer
    outMax: 1        # EXATAMENTE 1, use outMin=1.
    userFacingMessage: "Escolha no máximo um streaming."

# NEGAÇÃO "se NÃO... então": a entrada NONE não existe na DSL (a contagem é sobre
# produtos selecionados). Modele "não escolheu X" como uma condição sobre a
# SELEÇÃO de X, escolhendo o gatilho certo. Ex.: "quem NÃO leva iPhone Branco leva
# capa" vira: input = [iphone-branco], dispara quando NÃO está — porém a DSL só
# dispara sobre PRESENÇA. Então inverta: use o produto complementar como gatilho.
# ⚠️ Regras de "ausência" pura precisam de um produto-âncora presente. Ex.:
- id: negacao-ancorada
  nl: "Quem escolher o iPhone Preto (ou seja, não o Branco) deve levar a capa."
  expected:
    id: preto-requires-capa
    type: REQUIRES
    input:  [iphone-preto]     # âncora presente = "não escolheu o branco" no slot 1..1
    inMin:  1
    inMax:  1
    output: [capa]
    outMin: 1
    outMax: 1
    userFacingMessage: "Com o iPhone Preto, a capa é obrigatória."

# SINÔNIMO: a frase usa "aparelho branco"; o glossário mapeia para iphone-branco.
# (ver glossary.yaml — o tradutor resolve o sinônimo)
- id: sinonimo
  nl: "Se levar 30GB, o aparelho branco é obrigatório."
  expected:
    id: thirty-requires-branco
    type: REQUIRES
    input:  [30GB]
    inMin:  1
    inMax:  1
    output: [iphone-branco]
    outMin: 1
    outMax: 1
    userFacingMessage: "Com 30GB, o iPhone Branco é obrigatório."

# REGRA IMPOSSÍVEL (deve ser REJEITADA pelo serviço, com reason UNSATISFIABLE).
# Sirva de exemplo NEGATIVO — o "expected" aqui é o comportamento de rejeição.
- id: impossivel
  nl: "Se levar o iPhone Branco, então é obrigatório NÃO levar o iPhone Branco."
  expectedRejection: UNSATISFIABLE   # convenção do seu eval: marca que deve ser rejeitada
```

---

## 6. Como uma regra vira tabela-verdade (exemplo completo)

Pegue a regra **OR** (`or-requires-branco`): input `[20GB,30GB]` `in 1..2`, output
`[iphone-branco]` `out 1..1`, `REQUIRES`.

O sandbox enumera as configurações válidas da oferta Bolota. Como `plano` escolhe
1 de {fisica, juridica}, `fisica` escolhe 1 de {20GB,30GB}, etc., algumas
configurações possíveis (produtos selecionados) e o veredito da regra:

| Configuração (produtos selecionados) | count(input) | dispara? | count(output) | válido? |
|---|---|---|---|---|
| `{20GB, iphone-preto}`               | 1 | sim | 0 | **INVÁLIDO** (REQUIRES exige branco) |
| `{20GB, iphone-branco}`              | 1 | sim | 1 | VÁLIDO |
| `{30GB, iphone-branco}`              | 1 | sim | 1 | VÁLIDO |
| `{40GB, iphone-preto}`               | 0 | não | — | VÁLIDO (vacuamente) |
| `{50GB, iphone-branco}`              | 0 | não | — | VÁLIDO (vacuamente) |

Essa tabela é o **preview** que vai pro revisor humano e o que a **juíza** compara
com a frase original. Desenhá-la na mão no workshop é a melhor forma de pegar
ambiguidade cedo.

---

## 7. Checklist de cobertura

Um bom golden-set cobre, no mínimo:

- [ ] Cada uma das **7 portas** (NOT, AND, NAND, OR, NOR, XOR, XNOR).
- [ ] `REQUIRES` **e** `INCOMPATIBLE_WITH`.
- [ ] Janela de saída **além de 1..1** (ex.: 0..1, 2..3).
- [ ] Entrada com **3+ produtos** (aridade alta) e janelas `in k..k` e `in k..m`.
- [ ] Pelo menos **2 ambiguidades** com a decisão anotada ("apenas um", "ou").
- [ ] **Sinônimos** (frase usa termo coloquial; glossário resolve).
- [ ] Pelo menos **1 regra impossível** (deve ser rejeitada por `UNSATISFIABLE`).
- [ ] Regras derivadas de **3 ofertas reais** do seu catálogo.

---

## 8. Fase 2 — o golden-set vira gate de regressão em CI

Na Fase 2, um teste (`@Tag("eval")`) roda o golden-set contra a **LLM real** e
mede:

- **Exact match**: a regra gerada é igual à `expected` (ignorando `id` e mensagem).
- **Semantic match** (mais importante): a **tabela-verdade** da regra gerada é
  idêntica à da `expected`. Duas regras com forma diferente mas mesmo
  comportamento contam como acerto.

```bash
mvn test -Peval      # consome créditos de LLM
```

⚠️ **Cuidado estatístico:** com 12–15 exemplos, uma queda de "5%" é 1 exemplo
(ruído da não-determinância da LLM). Para o gate ser confiável:
- cresça o set para **50+**;
- rode **múltiplas seeds** e tire média;
- **trave num piso absoluto** (ex.: "semantic match ≥ 90%"), não num delta.

---

## 9. Anti-padrões

1. **Escrever o golden-set depois de codar** — ele é a spec, tem que vir antes.
2. **Não revisar cada `expected`** — a própria frase "escolha apenas um" tem duas
   leituras; o `expected` errado ensina a LLM a errar.
3. **Só casos fáceis** — sem ambiguidade/negação/impossível, o eval não protege de
   nada.
4. **Poucos exemplos e gate por delta** — estatística de ruído (ver seção 8).
5. **Deixar o golden-set desatualizado** quando a DSL evolui — ele tem que evoluir
   junto (é a documentação viva).

---

## 10. Template para copiar

```yaml
- id: <slug-do-exemplo>
  nl: "<frase EXATAMENTE como o negócio escreveria>"
  # opcional: por que esta é a interpretação correta (decisão de produto)
  # nota: "'apenas um' foi lido como no-máximo-1; confirmado com fulano em <data>"
  expected:
    id: <slug-da-regra-kebab-case>
    type: REQUIRES | INCOMPATIBLE_WITH
    input:  [<productId>, ...]
    inMin:  <int>
    inMax:  <int>
    output: [<productId>, ...]
    outMin: <int>
    outMax: <int>
    userFacingMessage: "<mensagem curta em PT-BR>"
```
